/*RUTINA*/
CREATE TABLE IF NOT EXISTS rutinas(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT,
            detalle TEXT,
            imagen TEXT,
            dias INTEGER,
            sistema TEXT,
            descansoEntreEjercicios INTEGER);
INSERT or IGNORE INTO rutinas VALUES (1, 'Torso-Pierna clasica 1',
                'Rutina divida en dos torso y pierna, pero también ligero - pesado',
                'assets/images/rutinas/torso-pierna-1.jpg', 4, 'Torso - Pierna', 90);
/*GRUPOSMUSCULARES*/
CREATE TABLE IF NOT EXISTS gruposMusculares(id INTEGER PRIMARY KEY AUTOINCREMENT,nombre TEXT,imagen TEXT);
INSERT or IGNORE INTO gruposMusculares VALUES (1, 'Dorsales', 'assets/images/grupos-musculares/dorsales.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (2, 'Pectorales', 'assets/images/grupos-musculares/pectorales.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (3, 'Hombro y cuello', 'assets/images/grupos-musculares/hombro.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (4, 'Biceps', 'assets/images/grupos-musculares/biceps.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (5, 'Triceps', 'assets/images/grupos-musculares/triceps.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (6, 'Piernas', 'assets/images/grupos-musculares/piernas.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (7, 'Zona Media', 'assets/images/grupos-musculares/zona-media.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (8, 'Cardiovascular', 'assets/images/grupos-musculares/cardio.jpg');
INSERT or IGNORE INTO gruposMusculares VALUES (9, 'Antebrazos', 'assets/images/grupos-musculares/antebrazos.jpg');
/*EJERCICIOS*/
CREATE TABLE IF NOT EXISTS ejercicios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        imagen TEXT,
        video TEXT,
        detalle TEXT,
        grupoMuscular INTEGER,
        usaBarra INTEGER,
        usaMancuernas INTEGER,
        usaPesoCorporal INTEGER,
        usaAgarres INTEGER,
        FOREIGN KEY(grupoMuscular) REFERENCES gruposMusculares(id)
      );

/*id,nombre,imagen,video,detalle,grupoMuscular,usaBarra,usaMancuernas,usaPesoCorporal,usaAgarres*/
INSERT or IGNORE INTO ejercicios VALUES 
(1, 'Press de banca inclinado con barra', 'assets/images/ejercicios/press-banca-inclinado-con-barra.png', '', '', 2, 1, 0, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(2, 'Remo con barra', 'assets/images/ejercicios/remo-con-barra.png', '', '', 1, 1, 0, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(3, 'Press militar', 'assets/images/ejercicios/press-militar.png', '', '', 3, 1, 0, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(4, 'Dominadas', 'assets/images/ejercicios/dominada-prona.png', '', '', 1, 0, 0, 1, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(5, 'Fondos en paralelas', 'assets/images/ejercicios/fondos.png', '', '', 5, 0, 0, 1, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(6, 'Sentadillas con barra', 'assets/images/ejercicios/sentadillas-con-barra.png', '', '', 6, 1, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(7, 'Peso muerto rumano', 'assets/images/ejercicios/peso-muerto-rumano.png', '', '', 6, 1, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(8, 'Prensa',  'assets/images/ejercicios/prensa.png', '', '', 6, 0, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(9, 'Zancadas con marcuernas', 'assets/images/ejercicios/zancadas-con-mancuernas.png', '', '', 6, 0, 1, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(10, 'Curl femoral acostado', 'assets/images/ejercicios/curl-femoral-acostado.png', '', '', 6, 0, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(11, 'Elevaciones de talones sentado', 'assets/images/ejercicios/elevacion-de-talones-sentado.png', '', '', 5, 0, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(12, 'Press de banca plano con barra', 'assets/images/ejercicios/press-banca-plano-con-barra.png', '', '', 2, 1, 0, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(13, 'Press de banca declinado con barra', 'assets/images/ejercicios/press-banca-declinado-con-barra.png', '', '', 1, 1, 0, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(14, 'Cruce de poleas', 'assets/images/ejercicios/cruce-de-poleas.png', '', '', 2, 0, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(15, 'Elevación de talones parado', 'assets/images/ejercicios/elevacion-de-talones-parado.png', '', '', 5, 0, 0, 0, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(16, 'Press de banca inclinado con mancuernas', 'assets/images/ejercicios/press-banca-inclinado-con-mancuernas.png', '', '', 2, 0, 1, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(17, 'Press de banca declinado con mancuernas', 'assets/images/ejercicios/press-banca-declinado-con-mancuernas.png', '', '', 1, 0, 1, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(18, 'Press de banca plano con mancuernas', 'assets/images/ejercicios/press-banca-plano-con-mancuernas.png', '', '', 2, 0, 1, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(19, 'Aperturas en banco plano con mancuernas', 'assets/images/ejercicios/aperturas-banco-plano-con-mancuernas.png', '', '', 2, 0, 1, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(20, 'Aperturas en banco inclinado con mancuernas', 'assets/images/ejercicios/aperturas-banco-inclinado-con-mancuernas.png', '', '', 2, 0, 1, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(21, 'Aperturas en banco declinado con mancuernas', 'assets/images/ejercicios/aperturas-banco-declinado-con-mancuernas.png', '', '', 2, 0, 1, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(22, 'Flexiones ', 'assets/images/ejercicios/flexiones.png', '', '', 5, 0, 0, 1, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(23, 'Flexiones pies en alto', 'assets/images/ejercicios/flexiones-pies-en-alto.png', '', '', 5, 0, 0, 1, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(24, 'Flexiones en la pared', 'assets/images/ejercicios/flexiones-en-la-pared.png', '', '', 5, 0, 0, 1, 0);
INSERT or IGNORE INTO ejercicios VALUES 
(25, 'Pull over con mancuerna', 'assets/images/ejercicios/pull-over-con-mancuerna.png', '', '', 2, 0, 0, 0, 1);
INSERT or IGNORE INTO ejercicios VALUES 
(26, 'Pull over con barra', 'assets/images/ejercicios/pull-over-con-barra.png', '', '', 2, 1, 0, 0, 1);

/*ejerciciosRutinas*/
CREATE TABLE IF NOT EXISTS ejerciciosRutinas(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rutina INTEGER,
        dia INTEGER,
        ejercicio INTEGER,
        descanso INTEGER,
        orden INTEGER,
        series INTEGER,
        candencia TEXT,
        anotacion TEXT,
        FOREIGN KEY(ejercicio) REFERENCES ejercicios(id),
        FOREIGN KEY(rutina) REFERENCES rutinas(id)
        );
INSERT or IGNORE INTO ejerciciosRutinas VALUES (1, 1, 1, 1, 120, 1, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (2, 1, 1, 2, 120, 2, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (3, 1, 1, 3, 90, 3, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (4, 1, 1, 4, 60, 4, 3, '1-0-2', 'Agarre neutro');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (5, 1, 1, 5, 60, 5, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (6, 1, 2, 6, 90, 1, 4, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (7, 1, 2, 7, 90, 2, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (8, 1, 2, 8, 60, 3, 2, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (9, 1, 2, 9, 30, 4, 2, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (10, 1, 2, 10, 60, 5, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (11, 1, 2, 11, 30, 6, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (12, 1, 3, 12, 90, 1, 4, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (13, 1, 3, 2, 90, 2, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (14, 1, 3, 3, 60, 3, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (15, 1, 3, 4, 90, 4, 3, '1-0-2', 'Agarre prono');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (16, 1, 3, 14, 60, 5, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (17, 1, 4, 6, 120, 1, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (18, 1, 4, 7, 120, 2, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (19, 1, 4, 8, 120, 3, 3, '1-0-2', '');
INSERT or IGNORE INTO ejerciciosRutinas VALUES (20, 1, 4, 15, 60, 4, 3, '1-0-2', '');
/*REPETICIONES-SERIE*/
 CREATE TABLE IF NOT EXISTS series (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ejercicioRutina INTEGER,
        repeticiones INTEGER,
        anotacion TEXT,
        FOREIGN KEY(ejercicioRutina) REFERENCES ejerciciosRutinas(id)
        );

INSERT or IGNORE INTO series VALUES(1,1,6,'');
INSERT or IGNORE INTO series VALUES(2,1,5,'');
INSERT or IGNORE INTO series VALUES(3,1,4,'A fallo');
INSERT or IGNORE INTO series VALUES(4,2,6,'');
INSERT or IGNORE INTO series VALUES(5,2,5,'');
INSERT or IGNORE INTO series VALUES(6,2,4,'A fallo');
INSERT or IGNORE INTO series VALUES(7,3,6,'');
INSERT or IGNORE INTO series VALUES(8,3,5,'');
INSERT or IGNORE INTO series VALUES(9,3,4,'A fallo');
INSERT or IGNORE INTO series VALUES(10,4,10,'');
INSERT or IGNORE INTO series VALUES(11,4,8,'');
INSERT or IGNORE INTO series VALUES(12,4,6,'A fallo');
INSERT or IGNORE INTO series VALUES(13,5,10,'');
INSERT or IGNORE INTO series VALUES(14,5,8,'A fallo');
INSERT or IGNORE INTO series VALUES(15,5,6,'A fallo');
INSERT or IGNORE INTO series VALUES(16,6,12,'');
INSERT or IGNORE INTO series VALUES(17,6,12,'');
INSERT or IGNORE INTO series VALUES(18,6,10,'');
INSERT or IGNORE INTO series VALUES(19,6,8,'');
INSERT or IGNORE INTO series VALUES(20,7,10,'');
INSERT or IGNORE INTO series VALUES(21,7,8,'');
INSERT or IGNORE INTO series VALUES(22,7,8,'');
INSERT or IGNORE INTO series VALUES(23,8,12,'');
INSERT or IGNORE INTO series VALUES(24,8,10,'');
INSERT or IGNORE INTO series VALUES(25,9,10,'');
INSERT or IGNORE INTO series VALUES(26,9,8,'');
INSERT or IGNORE INTO series VALUES(27,10,10,'');
INSERT or IGNORE INTO series VALUES(28,10,8,'');
INSERT or IGNORE INTO series VALUES(29,10,8,'');
INSERT or IGNORE INTO series VALUES(30,11,25,'');
INSERT or IGNORE INTO series VALUES(31,11,22,'');
INSERT or IGNORE INTO series VALUES(32,11,20,'');
INSERT or IGNORE INTO series VALUES(33,12,10,'');
INSERT or IGNORE INTO series VALUES(34,12,8,'');
INSERT or IGNORE INTO series VALUES(35,12,8,'');
INSERT or IGNORE INTO series VALUES(36,12,6,'');
INSERT or IGNORE INTO series VALUES(37,13,10,'');
INSERT or IGNORE INTO series VALUES(38,13,8,'');
INSERT or IGNORE INTO series VALUES(39,13,6,'');
INSERT or IGNORE INTO series VALUES(40,14,10,'');
INSERT or IGNORE INTO series VALUES(41,14,10,'');
INSERT or IGNORE INTO series VALUES(42,14,8,'');
INSERT or IGNORE INTO series VALUES(43,15,10,'');
INSERT or IGNORE INTO series VALUES(44,15,10,'');
INSERT or IGNORE INTO series VALUES(45,15,8,'');
INSERT or IGNORE INTO series VALUES(46,16,12,'');
INSERT or IGNORE INTO series VALUES(47,16,10,'');
INSERT or IGNORE INTO series VALUES(48,16,8,'');
INSERT or IGNORE INTO series VALUES(49,17,6,'');
INSERT or IGNORE INTO series VALUES(50,17,5,'');
INSERT or IGNORE INTO series VALUES(51,17,4,'A fallo');
INSERT or IGNORE INTO series VALUES(52,18,6,'');
INSERT or IGNORE INTO series VALUES(53,18,5,'');
INSERT or IGNORE INTO series VALUES(54,18,4,'A fallo');
INSERT or IGNORE INTO series VALUES(55,19,6,'');
INSERT or IGNORE INTO series VALUES(56,19,5,'');
INSERT or IGNORE INTO series VALUES(57,19,5,'A fallo');
INSERT or IGNORE INTO series VALUES(58,20,6,'');
INSERT or IGNORE INTO series VALUES(59,20,6,'');
INSERT or IGNORE INTO series VALUES(60,20,6,'A fallo');
/*REGISTRO*/
CREATE TABLE IF NOT EXISTS registros (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT,
        reps INTEGER,
        peso INTEGER,
        observ TEXT,
        ejercicio INTEGER,
        FOREIGN KEY(ejercicio) REFERENCES ejercicios(id)
        );
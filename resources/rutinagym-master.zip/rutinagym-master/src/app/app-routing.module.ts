import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {
    path: 'reglas',
    loadChildren: './pages/reglas/reglas.module#ReglasPageModule',
  },
  {
    path: 'rutinas',
    loadChildren: './pages/rutinas/rutinas.module#RutinasPageModule',
  },
  {
    path: 'aviso-calentamiento',
    loadChildren:
      './pages/aviso-calentamiento/aviso-calentamiento.module#AvisoCalentamientoPageModule',
  },
  {
    path: 'ejercicios-rutina-activa',
    loadChildren:
      './pages/ejercicios-rutina-activa/ejercicios-rutina-activa.module#EjerciciosRutinaActivaPageModule',
  },
  {
    path: 'series-ejercicio-rutina-activa',
    loadChildren:
      './pages/series-ejercicio-rutina-activa/series-ejercicio-rutina-activa.module#SeriesEjercicioRutinaActivaPageModule',
  },
  {
    path: 'descanso',
    loadChildren: './pages/descanso/descanso.module#DescansoPageModule',
  },
  {
    path: 'fin-actividad',
    loadChildren:
      './pages/fin-actividad/fin-actividad.module#FinActividadPageModule',
  },
  {
    path: 'configuracion',
    loadChildren:
      './pages/configuracion/configuracion.module#ConfiguracionPageModule',
  },
  {
    path: 'rutina-activa',
    loadChildren:
      './pages/rutina-activa/rutina-activa.module#RutinaActivaPageModule',
  },
  {
    path: 'usuario',
    loadChildren: './pages/usuario/usuario.module#UsuarioPageModule',
  },
  { path: 'home', loadChildren: './pages/home/home.module#HomePageModule' },
  {
    path: 'grupos-musculares',
    loadChildren:
      './pages/grupos-musculares/grupos-musculares.module#GruposMuscularesPageModule',
  },
  {
    path: 'ejercicios-por-grupo-muscular/:id',
    loadChildren:
      './pages/ejercicios-por-grupo-muscular/ejercicios-por-grupo-muscular.module#EjerciciosPorGrupoMuscularPageModule',
  },
  {
    path: 'registro-manual/:ejercicio',
    loadChildren:
      './pages/registro-manual/registro-manual.module#RegistroManualPageModule',
  },
  {
    path: 'registro/:id/:nombreEjercicio',
    loadChildren: './pages/registro/registro.module#RegistroPageModule',
  },
  {
    path: 'ejercicio/:id',
    loadChildren: './pages/ejercicio/ejercicio.module#EjercicioPageModule',
  },
  {
    path: 'grupo-muscular/:id',
    loadChildren:
      './pages/grupo-muscular/grupo-muscular.module#GrupoMuscularPageModule',
  },
  {
    path: 'rutina/:id',
    loadChildren: './pages/rutina/rutina.module#RutinaPageModule',
  },
  {
    path: 'ejercicios-rutina/:idRutina',
    loadChildren:
      './pages/ejercicios-rutina/ejercicios-rutina.module#EjerciciosRutinaPageModule',
  },
  {
    path: 'ejercicio-rutina/:id/:idRutina/:dia',
    loadChildren:
      './pages/ejercicio-rutina/ejercicio-rutina.module#EjercicioRutinaPageModule',
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}

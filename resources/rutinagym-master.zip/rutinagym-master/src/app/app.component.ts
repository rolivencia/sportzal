import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { ThemeService } from './services/theme.service';
import { AjustesService } from './services/ajustes.service';
import { UsuarioService } from './services/usuario.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private themeService: ThemeService,
    private ajustesService: AjustesService,
    private usuarioService: UsuarioService
  ) {
    this.initializeApp();
  }

  async initializeApp() {
    const cargaUsuario = this.usuarioService.cargar();
    const cargaAjustes = this.ajustesService.cargar();

    const platformReady = await this.platform.ready();
    const cargaDatosIniciales = await Promise.all([cargaUsuario, cargaAjustes]);
    this.statusBar.styleDefault();
    this.themeService.checkDarkTheme();
    this.splashScreen.hide();
  }
}

import { TestBed } from '@angular/core/testing';

import { SolicitudIdEjercicioService } from './solicitud-id-ejercicio.service';

describe('SolicitudIdEjercicioService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SolicitudIdEjercicioService = TestBed.get(SolicitudIdEjercicioService);
    expect(service).toBeTruthy();
  });
});

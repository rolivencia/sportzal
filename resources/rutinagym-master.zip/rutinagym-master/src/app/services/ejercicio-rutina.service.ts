import { Injectable } from '@angular/core';
import {
  EjercicioRutina,
  EjercicioRutinaConEjercicio,
} from '../models/ejercicio-rutina.model';
import { Ejercicio } from '../models/ejercicio.model';
import { DatabaseService } from './database/database.service';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class EjercicioRutinaService {
  public ejerciciosRutina: BehaviorSubject<
    EjercicioRutinaConEjercicio[]
  > = new BehaviorSubject([]);
  public idRutina;
  public ejercicioRutinaActivo: EjercicioRutina = null;

  constructor(private databaseService: DatabaseService) {}

  CargarEjerciciosRutina(idRutina: number): Promise<any> {
    this.idRutina = idRutina;
    let ejerciciosRutinaConEjercicio: EjercicioRutinaConEjercicio[] = [];
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService.loadActividadesDeRutina(idRutina).then(data => {
            console.log('sqldata', data);
            let ultimoIdEjercicioRutina = -1;
            let indiceEjercicioRutinaConEjercicio = -1;
            for (const ejRutina of data) {
              if (ultimoIdEjercicioRutina === ejRutina.erid) {
                ejerciciosRutinaConEjercicio[
                  indiceEjercicioRutinaConEjercicio
                ].repeticiones.push(ejRutina.repeticiones);
                ejerciciosRutinaConEjercicio[
                  indiceEjercicioRutinaConEjercicio
                ].anotaciones.push(ejRutina.rsanotacion);
              } else {
                let ejercicio: Ejercicio = new Ejercicio(
                  ejRutina.id,
                  ejRutina.nombre,
                  ejRutina.imagen,
                  ejRutina.video,
                  ejRutina.detalle,
                  ejRutina.grupoMuscular,
                  !!ejRutina.usaBarra,
                  !!ejRutina.usaMancuernas,
                  !!ejRutina.usaPesoCorporal,
                  !!ejRutina.usaAgarres
                );
                let ejercicioRutinaConEjercicio: EjercicioRutinaConEjercicio = new EjercicioRutinaConEjercicio(
                  ejRutina.erid,
                  ejRutina.rutina,
                  ejRutina.dia,
                  ejercicio,
                  ejRutina.descanso,
                  [ejRutina.repeticiones],
                  [ejRutina.rsanotacion],
                  ejRutina.erorden,
                  ejRutina.series,
                  ejRutina.candencia,
                  ejRutina.eranotacion
                );
                ejerciciosRutinaConEjercicio.push(ejercicioRutinaConEjercicio);
                ultimoIdEjercicioRutina = ejRutina.erid;
                indiceEjercicioRutinaConEjercicio++;
              }
            }

            console.log('CargarEjerciciosRutina', ejerciciosRutinaConEjercicio);
            this.ejerciciosRutina.next(ejerciciosRutinaConEjercicio);
          });
        }
      });
      resolve();
    });
  }

  AgregarEjercicioRutina(ejercicioRutina: EjercicioRutina): Promise<any> {
    return this.databaseService
      .addEjercicioRutina(
        ejercicioRutina.rutina,
        ejercicioRutina.ejercicio,
        ejercicioRutina.descanso,
        ejercicioRutina.orden,
        ejercicioRutina.series,
        ejercicioRutina.candencia,
        ejercicioRutina.dia,
        ejercicioRutina.anotacion
      )
      .then(() => {
        if (ejercicioRutina.rutina === this.idRutina) {
          this.CargarEjerciciosRutina(this.idRutina);
        }
      });
  }

  BorraEjercicioRutina(idEjercicioRutina: number): Promise<any> {
    console.log('id en BorraEjercicioRutina', idEjercicioRutina);
    return this.databaseService
      .deleteEjercicioRutina(idEjercicioRutina)
      .then(() => {
        this.CargarEjerciciosRutina(this.idRutina);
      });
  }

  GrabarEdicionEjercicioRutina(ejercicioRutina: EjercicioRutina): Promise<any> {
    return this.databaseService
      .updateEjercicioRutina(ejercicioRutina)
      .then(() => {
        if (ejercicioRutina.rutina === this.idRutina) {
          this.CargarEjerciciosRutina(this.idRutina);
        }
      });
  }

  getEjercicioRutina(idEjercicioRutina): Promise<EjercicioRutina> {
    return this.databaseService.getEjercicioRutina(idEjercicioRutina);
  }
}

import { Injectable } from '@angular/core';
import { ActividadesDia, ActividadDia } from '../models/actividadesdia.model';
import { UsuarioService } from '../services/usuario.service';
import { RutinaService } from '../services/rutina.service';
import { EjercicioRutinaService } from './ejercicio-rutina.service';
import { EjercicioService } from './ejercicio.service';
import { Ejercicio } from '../models/ejercicio.model';
import { BehaviorSubject, Observable } from 'rxjs';
import { DatabaseService } from './database/database.service';

@Injectable({
  providedIn: 'root',
})
export class ActividadesDiaService {
  actividadesdia: ActividadesDia = null;
  actividadesdiaB: BehaviorSubject<ActividadDia[]> = new BehaviorSubject([]);

  actividadActiva: ActividadDia = null;
  constructor(
    private usuarioService: UsuarioService,
    private rutinaService: RutinaService,
    private ejercicioRutinaService: EjercicioRutinaService,
    private ejercicioService: EjercicioService,
    private databaseService: DatabaseService
  ) {}

  loadActividades(idRutina: number, dia: number): Promise<ActividadDia[]> {
    let actividades: ActividadDia[] = [];
    return this.databaseService
      .loadActividadesDeRutinaYDia(idRutina, dia)
      .then(data => {
        console.log('sqldata', data);
        let ultimoIdEjercicioRutina = -1;
        let indiceActividad = -1;
        for (const ejRutina of data) {
          if (ultimoIdEjercicioRutina === ejRutina.erid) {
            actividades[indiceActividad].repeticiones.push(
              ejRutina.repeticiones
            );
            actividades[indiceActividad].repeticionesPendientes.push(
              ejRutina.repeticiones
            );
            actividades[indiceActividad].anotaciones.push(ejRutina.rsanotacion);
          } else {
            let ejercicio: Ejercicio = new Ejercicio(
              ejRutina.id,
              ejRutina.nombre,
              ejRutina.imagen,
              ejRutina.video,
              ejRutina.detalle,
              ejRutina.grupoMuscular,
              !!ejRutina.usaBarra,
              !!ejRutina.usaMancuernas,
              !!ejRutina.usaPesoCorporal,
              !!ejRutina.usaAgarres
            );
            let actividad: ActividadDia = new ActividadDia(
              ejercicio,
              ejRutina.descanso,
              ejRutina.erorden,
              ejRutina.series,
              ejRutina.candencia,
              ejRutina.eranotacion,
              [ejRutina.repeticiones],
              [ejRutina.rsanotacion],
              [],
              [],
              [ejRutina.repeticiones],
              true,
              false,
              false
            );
            actividades.push(actividad);
            ultimoIdEjercicioRutina = ejRutina.erid;
            indiceActividad++;
          }
        }

        console.log('actividades load', actividades);
        return actividades;
      });
  }

  getActividades(): Observable<ActividadDia[]> {
    return this.actividadesdiaB.asObservable();
  }

  CargarActividadesDia(): Promise<any> {
    this.actividadesdiaB.subscribe(obj => {
      this.actividadesdia.actividades = obj;
    });
    // cargo rutina
    console.log(
      'data usuario al cargar actividades dia',
      this.usuarioService.usuario
    );
    this.rutinaService.CargarRutina(this.usuarioService.usuario.rutina);
    // cargo dia
    return new Promise((resolve, reject) => {
      // cargo actividades
      this.loadActividades(
        this.usuarioService.usuario.rutina,
        this.usuarioService.usuario.dia
      ).then(actividades => {
        this.actividadesdia = new ActividadesDia(
          this.rutinaService.rutina,
          this.usuarioService.usuario.dia,
          actividades,
          actividades.length,
          0,
          0
        );
        console.log(this.actividadesdia.actividades);
        resolve();
      });
    });
  }

  CargarActividadActivaPorIndice(indiceActividad) {
    this.actividadActiva = this.actividadesdia.actividades[indiceActividad];
  }

  TerminarActividadActiva() {
    this.actividadActiva.pendiente = false;
    this.actividadActiva.realizada = true;
    this.actividadesdia.realizadas++;
    this.actividadesdia.pendientes--;
  }
  CancelarActividadActiva() {
    this.actividadActiva.pendiente = false;
    this.actividadActiva.cancelada = true;
    this.actividadesdia.canceladas++;
    this.actividadesdia.pendientes--;
  }
}

import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';

import { Ajustes } from '../models/ajustes.model';

@Injectable({
  providedIn: 'root',
})
export class AjustesService {
  ajustes: Ajustes = null;
  constructor(private storage: Storage) {
    console.log('CargoAjustesServices');
    //this.cargar();
  }
  cargar() {
    let promesa = new Promise((resolve, reject) => {
      this.storage.get('ajustes').then(
        val => {
          if (val) {
            //this.ajustes = JSON.parse(val) ;
            this.ajustes = val;
            resolve();
          } else {
            this.ajustes = new Ajustes();
            const prefersDark = window.matchMedia(
              '(prefers-color-scheme: dark)'
            );
            if (prefersDark) this.ajustes.temaOscuro = true;
            else this.ajustes.temaOscuro = false;
            this.salvar();
          }

          console.log('Los ajustes cargados', val);
        },
        error => {
          console.error('Error al cargar ajustes', error);
          this.ajustes = new Ajustes();
          const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
          if (prefersDark) this.ajustes.temaOscuro = true;
          else this.ajustes.temaOscuro = false;
          this.salvar();
        }
      );
    });
    return promesa;
  }

  salvar() {
    this.storage.set('ajustes', this.ajustes);
  }
}

import { Injectable } from '@angular/core';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';
import { SQLitePorter } from '@ionic-native/sqlite-porter/ngx';
import { HttpClient } from '@angular/common/http';
import { Platform } from '@ionic/angular';
import { BehaviorSubject, Observable } from 'rxjs';
import { GrupoMuscular } from 'src/app/models/grupo-muscular.model';
import { Ejercicio } from 'src/app/models/ejercicio.model';
import { Rutina } from 'src/app/models/rutina.models';
import { RegistroConEjercicio, Registro } from 'src/app/models/registro.model';
import { EjercicioRutina } from 'src/app/models/ejercicio-rutina.model';
import { Serie } from 'src/app/models/repeticiones-serie.model';

@Injectable({
  providedIn: 'root',
})
export class DatabaseService {
  private database: SQLiteObject;
  private dbReady: BehaviorSubject<boolean> = new BehaviorSubject(false);
  constructor(
    private plt: Platform,
    private sqlitePorter: SQLitePorter,
    private sqlite: SQLite,
    private http: HttpClient
  ) {
    this.plt.ready().then(() => {
      this.sqlite
        .create({
          name: 'entrenamiento.db',
          location: 'default',
        })
        .then((db: SQLiteObject) => {
          this.database = db;
          this.seedDatabase();
        });
    });
  }

  seedDatabase() {
    this.http
      .get('assets/data/seed.sql', { responseType: 'text' })
      .subscribe(sql => {
        this.sqlitePorter
          .importSqlToDb(this.database, sql)
          .then(() => {
            this.dbReady.next(true);
          })
          .catch(e => console.error(e));
      });
  }

  getDatabaseState() {
    return this.dbReady.asObservable();
  }

  getLastInsertRowId(): Promise<any> {
    return this.database
      .executeSql('SELECT last_insert_rowid() as lastId')
      .then(data => {
        console.log('data lastid', data);
        console.log('last id', data.rows.item(0).lastId);
        return data.rows.item(0).lastId;
      })
      .catch(error => {
        console.log(error);
      });
  }

  /*RUTINAS*/
  loadRutinas(): Promise<Rutina[]> {
    return this.database.executeSql('SELECT * FROM rutinas', []).then(data => {
      const rutinas: Rutina[] = [];
      if (data.rows.length > 0) {
        for (let i = 0; i < data.rows.length; i++) {
          rutinas.push({
            id: data.rows.item(i).id,
            nombre: data.rows.item(i).nombre,
            imagen: data.rows.item(i).imagen,
            detalle: data.rows.item(i).detalle,
            dias: data.rows.item(i).dias,
            sistema: data.rows.item(i).sistema,
            descansoEntreEjercicios: data.rows.item(i).descansoEntreEjercicios,
          });
        }
      }
      return rutinas;
    });
  }

  addRutina(
    nombre: string,
    detalle: string,
    imagen: string,
    dias: number,
    sistema: string,
    descansoEntreEjercicios: number
  ): Promise<any> {
    const data = [
      nombre,
      detalle,
      imagen,
      dias,
      sistema,
      descansoEntreEjercicios,
    ];
    console.log('data en addRutina', data);
    return this.database.executeSql(
      `INSERT INTO rutinas (nombre, detalle, imagen, dias, sistema, descansoEntreEjercicios)
         VALUES (?,?,?,?,?,?)`,
      data
    );
  }

  deleteRutina(id): Promise<any> {
    return this.database.executeSql(`DELETE FROM rutinas WHERE id = ?`, [id]);
  }

  updateRutina(rutina: Rutina) {
    const data = [
      rutina.nombre,
      rutina.detalle,
      rutina.imagen,
      rutina.dias,
      rutina.sistema,
      rutina.descansoEntreEjercicios,
    ];
    return this.database.executeSql(
      `UPDATE rutinas SET nombre = ?, detalle = ?, imagen = ?, dias = ?, sistema = ?,
              descansoEntreEjercicios = ? WHERE id = ${rutina.id}`,
      data
    );
  }

  getRutina(id: number): Promise<Rutina> {
    return this.database
      .executeSql('SELECT * FROM rutinas WHERE id = ?', [id])
      .then(data => {
        console.log(data);
        return {
          id: data.rows.item(0).id,
          nombre: data.rows.item(0).nombre,
          imagen: data.rows.item(0).imagen,
          detalle: data.rows.item(0).detalle,
          dias: data.rows.item(0).dias,
          sistema: data.rows.item(0).sistema,
          descansoEntreEjercicios: data.rows.item(0).descansoEntreEjercicios,
        };
      });
  }

  /*GRUPOS MUSCULARES*/
  loadGruposMusculares(): Promise<GrupoMuscular[]> {
    return this.database
      .executeSql('SELECT * FROM gruposMusculares ORDER BY nombre', [])
      .then(data => {
        const gruposMusculares: GrupoMuscular[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            gruposMusculares.push({
              id: data.rows.item(i).id,
              nombre: data.rows.item(i).nombre,
              imagen: data.rows.item(i).imagen,
            });
          }
        }
        return gruposMusculares;
      });
  }

  addGrupoMuscular(nombre: string, imagen: string): Promise<any> {
    const data = [nombre, imagen];
    console.log('data en addGrupoMuscular', data);
    return this.database.executeSql(
      'INSERT INTO gruposMusculares (nombre,imagen) VALUES (?,?)',
      data
    );
  }

  deleteGrupoMuscular(id): Promise<any> {
    return this.database.executeSql(
      `DELETE FROM gruposMusculares WHERE id = ?`,
      [id]
    );
  }

  updateGrupoMuscular(grupoMuscular: GrupoMuscular) {
    const data = [grupoMuscular.nombre, grupoMuscular.imagen];
    return this.database.executeSql(
      `UPDATE gruposMusculares SET nombre = ?, imagen = ? WHERE id = ${grupoMuscular.id}`,
      data
    );
  }

  getGrupoMuscular(id: number): Promise<GrupoMuscular> {
    return this.database
      .executeSql('SELECT * FROM gruposMusculares WHERE id = ?', [id])
      .then(data => {
        return {
          id: data.rows.item(0).id,
          nombre: data.rows.item(0).nombre,
          imagen: data.rows.item(0).imagen,
        };
      });
  }

  /*EJERCICIOS*/
  loadEjercicios(): Promise<Ejercicio[]> {
    return this.database
      .executeSql('SELECT * FROM ejercicios', [])
      .then(data => {
        const ejercicios: Ejercicio[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            ejercicios.push({
              id: data.rows.item(i).id,
              nombre: data.rows.item(i).nombre,
              imagen: data.rows.item(i).imagen,
              video: data.rows.item(i).video,
              detalle: data.rows.item(i).detalle,
              grupoMuscular: data.rows.item(i).grupoMuscular,
              usaBarra: !!data.rows.item(i).usaBarra,
              usaMancuernas: !!data.rows.item(i).usaMancuernas,
              usaPesoCorporal: !!data.rows.item(i).usaPesoCorporal,
              usaAgarres: !!data.rows.item(i).usaAgarres,
            });
          }
        }
        return ejercicios;
      });
  }

  loadEjerciciosPorGrupo(idGrupo: number): Promise<Ejercicio[]> {
    return this.database
      .executeSql('SELECT * FROM ejercicios WHERE grupoMuscular = ?', [idGrupo])
      .then(data => {
        const ejercicios: Ejercicio[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            ejercicios.push({
              id: data.rows.item(i).id,
              nombre: data.rows.item(i).nombre,
              imagen: data.rows.item(i).imagen,
              video: data.rows.item(i).video,
              detalle: data.rows.item(i).detalle,
              grupoMuscular: data.rows.item(i).grupoMuscular,
              usaBarra: !!data.rows.item(i).usaBarra,
              usaMancuernas: !!data.rows.item(i).usaMancuernas,
              usaPesoCorporal: !!data.rows.item(i).usaPesoCorporal,
              usaAgarres: !!data.rows.item(i).usaAgarres,
            });
          }
        }
        return ejercicios;
      });
  }

  addEjercicio(
    nombre: string,
    imagen: string,
    video: string,
    detalle: string,
    grupoMuscular: number,
    usaBarra: boolean,
    usaMancuernas: boolean,
    usaPesoCorporal: boolean,
    usaAgarres: boolean
  ): Promise<any> {
    const data = [
      nombre,
      imagen,
      video,
      detalle,
      grupoMuscular,
      usaBarra ? 1 : 0,
      usaMancuernas ? 1 : 0,
      usaPesoCorporal ? 1 : 0,
      usaAgarres ? 1 : 0,
    ];
    console.log('data en addEjercicio', data);
    return this.database.executeSql(
      `INSERT INTO ejercicios (nombre, imagen, video, detalle, grupoMuscular,
                                                              usaBarra, usaMancuernas, usaPesoCorporal,
                                                              usaAgarres)
                                     VALUES (?,?,?,?,?,?,?,?,?)`,
      data
    );
  }

  deleteEjercicio(id): Promise<any> {
    return this.database.executeSql(`DELETE FROM ejercicios WHERE id = ?`, [
      id,
    ]);
  }

  updateEjercicio(ejercicio: Ejercicio): Promise<any> {
    const data = [
      ejercicio.nombre,
      ejercicio.imagen,
      ejercicio.video,
      ejercicio.detalle,
      ejercicio.grupoMuscular,
      ejercicio.usaBarra ? 1 : 0,
      ejercicio.usaMancuernas ? 1 : 0,
      ejercicio.usaPesoCorporal ? 1 : 0,
      ejercicio.usaAgarres ? 1 : 0,
    ];
    return this.database.executeSql(
      `UPDATE ejercicios
        SET nombre = ?, imagen = ?, video = ?, detalle = ?, grupoMuscular = ?,
            usaBarra = ?, usaMancuernas = ?, usaPesoCorporal = ?,
            usaAgarres = ?
        WHERE id = ${ejercicio.id}`,
      data
    );
  }

  getEjercicio(id: number): Promise<Ejercicio> {
    return this.database
      .executeSql('SELECT * FROM ejercicios WHERE id = ?', [id])
      .then(data => {
        return {
          id: data.rows.item(0).id,
          nombre: data.rows.item(0).nombre,
          imagen: data.rows.item(0).imagen,
          video: data.rows.item(0).video,
          detalle: data.rows.item(0).detalle,
          grupoMuscular: data.rows.item(0).grupoMuscular,
          usaBarra: !!data.rows.item(0).usaBarra,
          usaMancuernas: !!data.rows.item(0).usaMancuernas,
          usaPesoCorporal: !!data.rows.item(0).usaPesoCorporal,
          usaAgarres: !!data.rows.item(0).usaAgarres,
        };
      });
  }

  /*ACTIVIDADES son los ejericios-rutina al momento de realizarlos Y EJERCICIOS-RUTINA*/
  loadActividadesDeRutinaYDia(idRutina, dia): Promise<any[]> {
    console.log('rutina ', idRutina, 'dia', dia);
    return this.database
      .executeSql(
        `select e_r.id as erid, e_r.descanso,e_r.orden as erorden, e_r.series, e_r.candencia, e_r.anotacion as eranotacion,
              r_s.ejercicioRutina, r_s.id as rsorden, r_s.repeticiones, r_s.anotacion as rsanotacion,
              e.*
      from ejerciciosRutinas as e_r
      left join ejercicios as e
      on e_r.ejercicio = e.id
      left join series as r_s
      on r_s.ejercicioRutina = e_r.id
      where e_r.rutina = ?
      and e_r.dia = ?
      order by e_r.orden, r_s.id`,
        [idRutina, dia]
      )
      .then(data => {
        const info: any[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            info.push({
              erid: data.rows.item(i).erid,
              descanso: data.rows.item(i).descanso,
              erorden: data.rows.item(i).erorden,
              series: data.rows.item(i).series,
              candencia: data.rows.item(i).candencia,
              eranotacion: data.rows.item(i).eranotacion,
              ejercicioRutina: data.rows.item(i).ejercicioRutina,
              rsorden: data.rows.item(i).rsorden,
              repeticiones: data.rows.item(i).repeticiones,
              rsanotacion: data.rows.item(i).rsanotacion,
              id: data.rows.item(i).id,
              nombre: data.rows.item(i).nombre,
              imagen: data.rows.item(i).imagen,
              video: data.rows.item(i).video,
              detalle: data.rows.item(i).detalle,
              grupoMuscular: data.rows.item(i).grupoMuscular,
              usaBarra: data.rows.item(i).usaBarra,
              usaMancuernas: data.rows.item(i).usaMancuernas,
              usaPesoCorporal: data.rows.item(i).usaPesoCorporal,
              usaAgarres: data.rows.item(i).usaAgarres,
            });
          }
        }
        return info;
      });
  }

  loadActividadesDeRutina(idRutina): Promise<any[]> {
    console.log('rutina ', idRutina);
    return this.database
      .executeSql(
        `select e_r.id as erid, e_r.rutina, e_r.dia, e_r.descanso,e_r.orden as erorden, e_r.series,
              e_r.candencia, e_r.anotacion as eranotacion,
              r_s.ejercicioRutina, r_s.id as rsorden, r_s.repeticiones, r_s.anotacion as rsanotacion,
              e.*
      from ejerciciosRutinas as e_r
      left join ejercicios as e
      on e_r.ejercicio = e.id
      left join series as r_s
      on r_s.ejercicioRutina = e_r.id
      where e_r.rutina = ?
      order by e_r.dia, e_r.orden, r_s.id`,
        [idRutina]
      )
      .then(data => {
        const info: any[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            info.push({
              erid: data.rows.item(i).erid,
              rutina: data.rows.item(i).rutina,
              dia: data.rows.item(i).dia,
              descanso: data.rows.item(i).descanso,
              erorden: data.rows.item(i).erorden,
              series: data.rows.item(i).series,
              candencia: data.rows.item(i).candencia,
              eranotacion: data.rows.item(i).eranotacion,
              ejercicioRutina: data.rows.item(i).ejercicioRutina,
              rsorden: data.rows.item(i).rsorden,
              repeticiones: data.rows.item(i).repeticiones,
              rsanotacion: data.rows.item(i).rsanotacion,
              id: data.rows.item(i).id,
              nombre: data.rows.item(i).nombre,
              imagen: data.rows.item(i).imagen,
              video: data.rows.item(i).video,
              detalle: data.rows.item(i).detalle,
              grupoMuscular: data.rows.item(i).grupoMuscular,
              usaBarra: data.rows.item(i).usaBarra,
              usaMancuernas: data.rows.item(i).usaMancuernas,
              usaPesoCorporal: data.rows.item(i).usaPesoCorporal,
              usaAgarres: data.rows.item(i).usaAgarres,
            });
          }
        }
        return info;
      });
  }
  addEjercicioRutina(
    rutina: number,
    ejercicio: number,
    descanso: number,
    orden: number,
    series: number,
    candencia: string,
    dia: number,
    anotacion: string
  ): Promise<any> {
    const data = [
      rutina,
      ejercicio,
      descanso,
      orden,
      series,
      candencia,
      dia,
      anotacion,
    ];
    console.log('data en addEjercicioRutina', data);
    return this.database.executeSql(
      'INSERT INTO ejerciciosRutinas(rutina, ejercicio, descanso, orden, series, candencia, dia, anotacion) VALUES (?,?,?,?,?,?,?,?)',
      data
    );
  }

  deleteEjercicioRutina(id): Promise<any> {
    return this.database.executeSql(
      `DELETE FROM ejerciciosRutinas WHERE id = ?`,
      [id]
    );
  }

  updateEjercicioRutina(ejercicioRutina: EjercicioRutina) {
    // La rutina no se cambiaria, no se va poder intercambiar ejercicio-rutina entre ejercicios
    const data = [
      ejercicioRutina.ejercicio,
      ejercicioRutina.descanso,
      ejercicioRutina.orden,
      ejercicioRutina.series,
      ejercicioRutina.candencia,
      ejercicioRutina.dia,
      ejercicioRutina.anotacion,
    ];
    return this.database.executeSql(
      `UPDATE ejerciciosRutinas SET ejercicio = ?, descanso = ?, orden = ?,
                                     series = ?, candencia = ?, dia = ?, anotacion = ?
                                     WHERE id = ${ejercicioRutina.id}`,
      data
    );
  }

  getEjercicioRutina(id: number): Promise<EjercicioRutina> {
    return this.database
      .executeSql('SELECT * FROM ejerciciosRutinas WHERE id = ?', [id])
      .then(data => {
        return {
          id: data.rows.item(0).id,
          rutina: data.rows.item(0).rutina,
          ejercicio: data.rows.item(0).ejercicio,
          descanso: data.rows.item(0).descanso,
          orden: data.rows.item(0).orden,
          series: data.rows.item(0).series,
          candencia: data.rows.item(0).candencia,
          dia: data.rows.item(0).dia,
          anotacion: data.rows.item(0).anotacion,
        };
      });
  }

  /*REPETICIONES-SERIES*/
  loadSeriesPorEjercicioRutina(idEjercicioRutina: number): Promise<Serie[]> {
    return this.database
      .executeSql('SELECT * FROM series WHERE ejercicioRutina = ?', [
        idEjercicioRutina,
      ])
      .then(data => {
        const series: Serie[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            series.push({
              id: data.rows.item(i).id,
              ejercicioRutina: data.rows.item(i).ejercicioRutina,
              repeticiones: data.rows.item(i).repeticiones,
              anotacion: data.rows.item(i).anotacion,
            });
          }
        }
        return series;
      });
  }

  addSerie(
    ejercicioRutina: number,
    repeticiones: number,
    anotacion: string
  ): Promise<any> {
    const data = [ejercicioRutina, repeticiones, anotacion];
    console.log('data en addRepeticion', data);
    return this.database.executeSql(
      `INSERT INTO series (ejercicioRutina, repeticiones, anotacion)
                                    VALUES (?,?,?)`,
      data
    );
  }

  deleteSerie(id): Promise<any> {
    return this.database.executeSql(`DELETE FROM series WHERE id = ?`, [id]);
  }

  updateSerie(series: Serie): Promise<any> {
    const data = [
      series.ejercicioRutina,
      series.repeticiones,
      series.anotacion,
    ];
    return this.database.executeSql(
      `UPDATE series
        SET ejercicioRutina = ?, repeticiones = ?, anotacion = ?
        WHERE id = ${series.id}`,
      data
    );
  }

  getSerie(id: number): Promise<Serie> {
    return this.database
      .executeSql('SELECT * FROM series WHERE id = ?', [id])
      .then(data => {
        return {
          id: data.rows.item(0).id,
          ejercicioRutina: data.rows.item(0).ejercicioRutina,
          repeticiones: data.rows.item(0).repeticiones,
          anotacion: data.rows.item(0).anotacion,
        };
      });
  }

  /*REGISTROS*/
  loadRegistrosxFecha(fecha: string): Promise<RegistroConEjercicio[]> {
    return this.database
      .executeSql(
        `SELECT r.id, r.fecha, r.ejercicio,
          e.nombre as nombreEjercicio, r.reps, r.peso, r.observ
          FROM registros as r
          LEFT JOIN ejercicios as e
          ON e.id = r.ejercicio
          WHERE r.fecha = ?
          ORDER BY e.nombre`,
        [fecha]
      )
      .then(data => {
        const registrosxfecha: RegistroConEjercicio[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            registrosxfecha.push({
              id: data.rows.item(i).id,
              fecha: data.rows.item(i).fecha,
              ejercicio: data.rows.item(i).ejercicio,
              nombreEjercicio: data.rows.item(i).nombreEjercicio,
              reps: data.rows.item(i).reps,
              peso: data.rows.item(i).peso,
              observ: data.rows.item(i).observ,
            });
          }
        }
        return registrosxfecha;
      });
  }

  loadRegistrosxEjercicio(
    idEjercicio: number
  ): Promise<RegistroConEjercicio[]> {
    return this.database
      .executeSql(
        `SELECT r.id, r.fecha, r.ejercicio,
          e.nombre as nombreEjercicio, r.reps, r.peso, r.observ
          FROM registros as r
          LEFT JOIN ejercicios as e
          ON e.id = r.ejercicio
          WHERE r.ejercicio = ?
          ORDER BY r.fecha DESC`,
        [idEjercicio]
      )
      .then(data => {
        const registrosxejercicio: RegistroConEjercicio[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            console.log('fila registros por ejercicio', data.rows.item(i));
            registrosxejercicio.push({
              id: data.rows.item(i).id,
              fecha: data.rows.item(i).fecha,
              ejercicio: data.rows.item(i).ejercicio,
              nombreEjercicio: data.rows.item(i).nombreEjercicio,
              reps: data.rows.item(i).reps,
              peso: data.rows.item(i).peso,
              observ: data.rows.item(i).observ,
            });
          }
        }
        console.log('RegistrosxEjercicioEnLoad', registrosxejercicio);
        return registrosxejercicio;
      });
  }

  loadRegistrosxEjercicioyFecha(
    idEjercicio: number,
    fecha: string
  ): Promise<RegistroConEjercicio[]> {
    return this.database
      .executeSql(
        `SELECT r.id, r.fecha, r.ejercicio,
          e.nombre as nombreEjercicio, r.reps, r.peso, r.observ
          FROM registros as r
          LEFT JOIN ejercicios as e
          ON e.id = r.ejercicio
          WHERE r.ejercicio = ?
          AND r.fecha = ?
          ORDER BY e.nombre`,
        [idEjercicio, fecha]
      )
      .then(data => {
        const registrosxejercicioyfecha: RegistroConEjercicio[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            console.log('fila registros por ejercicio', data.rows.item(i));
            registrosxejercicioyfecha.push({
              id: data.rows.item(i).id,
              fecha: data.rows.item(i).fecha,
              ejercicio: data.rows.item(i).ejercicio,
              nombreEjercicio: data.rows.item(i).nombreEjercicio,
              reps: data.rows.item(i).reps,
              peso: data.rows.item(i).peso,
              observ: data.rows.item(i).observ,
            });
          }
        }
        console.log('RegistrosxEjercicioyFecha', registrosxejercicioyfecha);
        return registrosxejercicioyfecha;
      });
  }

  loadRegistrosxEjercicioyUltimaFecha(
    idEjercicio: number,
    fecha: string
  ): Promise<RegistroConEjercicio[]> {
    return this.database
      .executeSql(
        `SELECT r.id, r.fecha, r.ejercicio,
          e.nombre as nombreEjercicio, r.reps, r.peso, r.observ
          FROM registros as r
          LEFT JOIN ejercicios as e
          ON e.id = r.ejercicio
          WHERE r.ejercicio = ?
          AND r.fecha = (select max(r1.fecha)
                          from registros as r1
                          where r1.fecha != ? )
          ORDER BY e.nombre`,
        [idEjercicio, fecha]
      )
      .then(data => {
        const registrosxejercicioyultimafecha: RegistroConEjercicio[] = [];
        if (data.rows.length > 0) {
          for (let i = 0; i < data.rows.length; i++) {
            console.log('fila registros por ejercicio', data.rows.item(i));
            registrosxejercicioyultimafecha.push({
              id: data.rows.item(i).id,
              fecha: data.rows.item(i).fecha,
              ejercicio: data.rows.item(i).ejercicio,
              nombreEjercicio: data.rows.item(i).nombreEjercicio,
              reps: data.rows.item(i).reps,
              peso: data.rows.item(i).peso,
              observ: data.rows.item(i).observ,
            });
          }
        }
        console.log(
          'RegistrosxEjercicioyUltimaFecha',
          registrosxejercicioyultimafecha
        );
        return registrosxejercicioyultimafecha;
      });
  }

  addRegistro(
    fecha: string,
    ejercicio: number,
    reps: number,
    peso: number,
    observ: string
  ): Promise<any> {
    const data = [fecha, ejercicio, reps, peso, observ];
    console.log('data en addregistro', data);
    return this.database.executeSql(
      'INSERT INTO registros (fecha, ejercicio, reps, peso, observ) VALUES (?,?,?,?,?)',
      data
    );
  }

  deleteRegistro(id): Promise<any> {
    return this.database.executeSql(`DELETE FROM registros WHERE id = ?`, [id]);
  }

  updateRegistro(registro: Registro) {
    const data = [
      registro.fecha.slice(0, 10),
      registro.ejercicio,
      registro.reps,
      registro.peso,
      registro.observ,
    ];
    return this.database.executeSql(
      `UPDATE registros SET fecha = ?, ejercicio = ?, reps = ?, peso = ?, observ = ? WHERE id = ${registro.id}`,
      data
    );
  }

  getRegistro(id: number): Promise<Registro> {
    return this.database
      .executeSql('SELECT * FROM registros WHERE id = ?', [id])
      .then(data => {
        return {
          id: data.rows.item(0).id,
          fecha: data.rows.item(0).fecha,
          ejercicio: data.rows.item(0).ejercicio,
          reps: data.rows.item(0).reps,
          peso: data.rows.item(0).peso,
          observ: data.rows.item(0).observ,
        };
      });
  }
}

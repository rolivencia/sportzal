import { Injectable } from '@angular/core';
import { Rutina } from '../models/rutina.models';
import { DatabaseService } from './database/database.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { EjercicioRutinaConEjercicio } from '../models/ejercicio-rutina.model';
import { Ejercicio } from '../models/ejercicio.model';

@Injectable({
  providedIn: 'root',
})
export class RutinaService {
  rutinas: BehaviorSubject<Rutina[]> = new BehaviorSubject([]);
  rutina: Rutina;
  constructor(private databaseService: DatabaseService) {
    this.CargarRutinas();
    console.log('cargo rutinas');
  }

  getRutinas(): Observable<Rutina[]> {
    return this.rutinas.asObservable();
  }

  CargarRutinas() {
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService.loadRutinas().then(rutinas => {
            this.rutinas.next(rutinas);
            console.log('rutinas', this.rutinas);
          });
        }
      });
      resolve();
    });
  }

  AgregarRutina(rutina: Rutina): Promise<any> {
    return this.databaseService
      .addRutina(
        rutina.nombre,
        rutina.detalle,
        rutina.imagen,
        rutina.dias,
        rutina.sistema,
        rutina.descansoEntreEjercicios
      )
      .then(results => {
        const idInsertado = results.insertId;
        this.CargarRutinas();
        return idInsertado;
      });
  }

  BorrarRutina(idRutina: number): Promise<any> {
    console.log('id en BorrarRutina', idRutina);
    return this.databaseService.deleteRutina(idRutina).then(() => {
      this.CargarRutinas().then(() => {
        if (this.rutina.id === idRutina) {
          this.rutina = {} as Rutina;
        }
      });
    });
  }

  GrabarEdicionRutina(rutina: Rutina): Promise<any> {
    return this.databaseService.updateRutina(rutina).then(() => {
      this.CargarRutinas().then(() => {
        if (this.rutina.id === rutina.id) {
          this.CargarRutina(this.rutina.id);
        }
      });
    });
  }

  CargarRutina(id: number): void {
    this.rutina = this.rutinas.getValue().find(arutina => arutina.id === id);
  }

  getRutina(idRutina): Promise<Rutina> {
    return this.databaseService.getRutina(idRutina);
  }
}

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class DatosEstadisticosEntrenamientoActualService {
  public tiempoInicio: number;
  public tiempoFin: number;
  public tiempoDescanso: number;
  constructor() {
    this.tiempoInicio = 0;
    this.tiempoFin = 0;
    this.tiempoDescanso = 0;
  }
}

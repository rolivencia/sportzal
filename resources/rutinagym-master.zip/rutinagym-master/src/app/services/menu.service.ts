import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ComponenteMenu } from '../models/menu.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  constructor(private http: HttpClient) {}
  getMenuOptions(): Observable<ComponenteMenu[]> {
    return this.http.get<ComponenteMenu[]>('/assets/data/menu.json');
  }
}

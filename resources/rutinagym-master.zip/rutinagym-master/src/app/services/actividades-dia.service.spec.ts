import { TestBed } from '@angular/core/testing';

import { ActividadesDiaService } from './actividades-dia.service';

describe('ActividadesDiaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ActividadesDiaService = TestBed.get(ActividadesDiaService);
    expect(service).toBeTruthy();
  });
});

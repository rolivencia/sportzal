import { Injectable } from '@angular/core';
import { AjustesService } from './ajustes.service';

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  constructor(private ajustesService: AjustesService) {}
  obtenerSiEsDarkThemeSistema() {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    return prefersDark;
  }

  checkDarkTheme() {
    // const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    // if(!prefersDark){
    if (!this.ajustesService.ajustes.temaOscuro) {
      document.body.classList.toggle('dark');
    }
    // }
  }
  cambio() {
    this.ajustesService.ajustes.temaOscuro = !this.ajustesService.ajustes
      .temaOscuro;
    this.ajustesService.salvar();
    document.body.classList.toggle('dark');
  }
}

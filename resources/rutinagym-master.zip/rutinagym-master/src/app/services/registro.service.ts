import { Injectable } from '@angular/core';
import { DatabaseService } from './database/database.service';
import { RegistroConEjercicio, Registro } from '../models/registro.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RegistroService {
  registrosxfecha: BehaviorSubject<
    RegistroConEjercicio[]
  > = new BehaviorSubject([]);
  registrosxejercicio: BehaviorSubject<
    RegistroConEjercicio[]
  > = new BehaviorSubject([]);

  ejercicioderegistro: number = null;
  fechaderegistro: string = null;

  constructor(private databaseService: DatabaseService) {}

  CargarRegistrosxFecha(fecha: string): Promise<any> {
    this.fechaderegistro = fecha;
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService
            .loadRegistrosxFecha(this.fechaderegistro.slice(0, 10))
            .then(registros => {
              this.registrosxfecha.next(registros);
              console.log('registros x fecha', this.registrosxfecha.getValue());
            });
        }
      });
      resolve();
    });
  }

  CargarRegistrosxEjercicio(idEjercicio: number): Promise<any> {
    this.ejercicioderegistro = idEjercicio;
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService
            .loadRegistrosxEjercicio(this.ejercicioderegistro)
            .then(registros => {
              this.registrosxejercicio.next(registros);
              console.log(
                'registros x ejercicio',
                this.registrosxejercicio.getValue()
              );
            });
        }
      });
      resolve();
    });
  }
  ObtenerRegistrosxEjercicioyFecha(
    idEjercicio: number,
    fecha: string
  ): Promise<RegistroConEjercicio[]> {
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService
            .loadRegistrosxEjercicioyFecha(idEjercicio, fecha)
            .then(registros => {
              console.log('registros x ejercicio y fecha', registros);
              resolve(registros);
            });
        }
      });
    });
  }
  ObtenerRegistrosxEjercicioyUltimaFecha(
    idEjercicio: number,
    fecha: string
  ): Promise<RegistroConEjercicio[]> {
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService
            .loadRegistrosxEjercicioyUltimaFecha(idEjercicio, fecha)
            .then(registros => {
              console.log('registros x ejercicio y ultima fecha', registros);
              resolve(registros);
            });
        }
      });
    });
  }

  AgregarRegistro(registro: Registro): Promise<any> {
    return this.databaseService
      .addRegistro(
        registro.fecha.slice(0, 10),
        registro.ejercicio,
        registro.reps,
        registro.peso,
        registro.observ
      )
      .then(() => {
        if (this.ejercicioderegistro) {
          this.CargarRegistrosxEjercicio(this.ejercicioderegistro);
        }
        if (this.fechaderegistro) {
          this.CargarRegistrosxFecha(this.fechaderegistro);
        }
      });
  }

  BorrarRegistro(idRegistro: number): Promise<any> {
    console.log('id en borrarregistro', idRegistro);
    return this.databaseService.deleteRegistro(idRegistro).then(() => {
      if (this.ejercicioderegistro) {
        this.CargarRegistrosxEjercicio(this.ejercicioderegistro);
      }
      if (this.fechaderegistro) {
        this.CargarRegistrosxFecha(this.fechaderegistro);
      }
    });
  }

  GrabarEdicionRegistro(registro: Registro): Promise<any> {
    return this.databaseService.updateRegistro(registro).then(() => {
      if (this.ejercicioderegistro) {
        this.CargarRegistrosxEjercicio(this.ejercicioderegistro);
      }
      if (this.fechaderegistro) {
        this.CargarRegistrosxFecha(this.fechaderegistro);
      }
    });
  }

  getRegistro(idRegistro): Promise<Registro> {
    return this.databaseService.getRegistro(idRegistro);
  }
}

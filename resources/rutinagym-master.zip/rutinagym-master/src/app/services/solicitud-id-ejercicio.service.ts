import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { EjercicioRutinaService } from './ejercicio-rutina.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SolicitudIdEjercicioService {
  idEjercicio: number = null;
  solicitudAbierta = false;
  rutaInicio: string = null;
  rutaDestino: string = null;
  solicitudReady: BehaviorSubject<boolean> = new BehaviorSubject(false);
  constructor(
    private router: Router,
    private ejercicioRutinaService: EjercicioRutinaService
  ) {}

  EmitirSolicitudIdEjercicio(rutaDestino, SinFiltarPorGrupo = false) {
    this.solicitudReady.next(false);
    this.solicitudAbierta = true;
    this.rutaDestino = rutaDestino;
    if (SinFiltarPorGrupo) {
      this.router.navigate(['/ejercicios-por-grupo-muscular']);
    } else {
      this.router.navigate(['/grupos-musculares']);
    }
  }

  RetornarIdEjercicio(idEjercicio) {
    this.idEjercicio = idEjercicio;
    if (this.rutaDestino.substring(0, 18) === '/ejercicio-rutina/') {
      this.ejercicioRutinaService.ejercicioRutinaActivo.ejercicio = this.idEjercicio;
      const array = this.rutaDestino.split('/');

      const rutaDestino = '/ejercicio-rutina/';
      const idEjercicioRutina = array[2];
      const idRutina = array[3];
      const dia = array[4];

      this.router.navigate([rutaDestino, idEjercicioRutina, idRutina, dia]);
    } else {
      this.router.navigate([this.rutaDestino, this.idEjercicio]);
    }
    this.solicitudReady.next(true);
  }
  CerrarSolicitud() {
    this.solicitudAbierta = false;
    this.rutaDestino = null;
    this.rutaInicio = null;
  }
}

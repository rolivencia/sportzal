import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { GrupoMuscular } from '../models/grupo-muscular.model';
import { DatabaseService } from './database/database.service';

@Injectable({
  providedIn: 'root',
})
export class GrupoMuscularService {
  gruposMusculares: BehaviorSubject<GrupoMuscular[]> = new BehaviorSubject([]);
  constructor(private databaseService: DatabaseService) {
    this.CargarGruposMusculares();
  }

  CargarGruposMusculares(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService.loadGruposMusculares().then(gruposMusculares => {
            this.gruposMusculares.next(gruposMusculares);
            console.log('grupos musculares', this.gruposMusculares);
          });
        }
      });
      resolve();
    });
  }

  AgregarGrupoMuscular(grupoMuscular: GrupoMuscular): Promise<any> {
    return this.databaseService
      .addGrupoMuscular(grupoMuscular.nombre, grupoMuscular.imagen)
      .then(() => {
        this.CargarGruposMusculares();
      });
  }

  BorrarGrupoMuscular(idGrupoMuscular: number): Promise<any> {
    console.log('id en BorrarGrupoMuscular', idGrupoMuscular);
    return this.databaseService
      .deleteGrupoMuscular(idGrupoMuscular)
      .then(() => {
        this.CargarGruposMusculares();
      });
  }

  GrabarEdicionGrupoMuscular(grupoMuscular: GrupoMuscular): Promise<any> {
    return this.databaseService.updateGrupoMuscular(grupoMuscular).then(() => {
      this.CargarGruposMusculares();
    });
  }

  getGrupoMuscular(idGrupoMuscular): Promise<GrupoMuscular> {
    return this.databaseService.getGrupoMuscular(idGrupoMuscular);
  }
}

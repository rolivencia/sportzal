import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { Usuario } from '../models/usuario.model';

@Injectable({
  providedIn: 'root',
})
export class UsuarioService {
  usuario: Usuario = null;
  constructor(private storage: Storage) {}
  cargar() {
    const promesa = new Promise((resolve, reject) => {
      this.storage.get('usuario').then(
        val => {
          if (val) {
            this.usuario = val;
          } else {
            this.usuario = new Usuario(1, 'Andres', 1, 1, 1, 0, 75, 172);
            this.salvar();
          }
          resolve();
          console.log('El usuario Cargado', this.usuario);
        },
        error => {
          console.error('Error al cargar usuario', error);
          this.usuario = new Usuario(1, 'Andres', 1, 1, 1, 0, 75);
          this.salvar();
        }
      );
    });
    return promesa;
  }

  salvar() {
    this.storage.set('usuario', this.usuario);
  }
}

import { Injectable } from '@angular/core';
import { Ejercicio } from '../models/ejercicio.model';
import { DatabaseService } from './database/database.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EjercicioService {
  ejercicios: BehaviorSubject<Ejercicio[]> = new BehaviorSubject([]);
  ejerciciosPorGrupoMuscular: BehaviorSubject<
    Ejercicio[]
  > = new BehaviorSubject([]);
  idGrupoMuscular: number = null;

  constructor(private databaseService: DatabaseService) {
    this.CargarEjercicios();
  }

  CargarEjercicios(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService.loadEjercicios().then(ejercicios => {
            this.ejercicios.next(ejercicios);
            console.log('ejercicios', this.ejercicios);
          });
        }
      });
      resolve();
    });
  }

  CargarEjerciciosPorGrupo(idGrupoMuscular: number): Promise<any> {
    this.idGrupoMuscular = idGrupoMuscular;
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService
            .loadEjerciciosPorGrupo(this.idGrupoMuscular)
            .then(ejercicios => {
              this.ejerciciosPorGrupoMuscular.next(ejercicios);
              console.log(
                'ejerciciosPorGrupoMuscular',
                this.ejerciciosPorGrupoMuscular
              );
            });
        }
      });
      resolve();
    });
  }

  AgregarEjercicio(ejercicio: Ejercicio): Promise<any> {
    return this.databaseService
      .addEjercicio(
        ejercicio.nombre,
        ejercicio.imagen,
        ejercicio.video,
        ejercicio.detalle,
        ejercicio.grupoMuscular,
        ejercicio.usaBarra,
        ejercicio.usaMancuernas,
        ejercicio.usaPesoCorporal,
        ejercicio.usaAgarres
      )
      .then(() => {
        this.CargarEjercicios();
        if (this.idGrupoMuscular) {
          this.CargarEjerciciosPorGrupo(this.idGrupoMuscular);
        }
      });
  }

  BorrarEjercicio(idEjercicio: number): Promise<any> {
    return this.databaseService.deleteEjercicio(idEjercicio).then(() => {
      this.CargarEjercicios();
      if (this.idGrupoMuscular) {
        this.CargarEjerciciosPorGrupo(this.idGrupoMuscular);
      }
    });
  }

  GrabarEdicionEjercicio(ejercicio: Ejercicio): Promise<any> {
    return this.databaseService.updateEjercicio(ejercicio).then(() => {
      this.CargarEjercicios();
      if (this.idGrupoMuscular) {
        this.CargarEjerciciosPorGrupo(this.idGrupoMuscular);
      }
    });
  }

  getEjercicio(idEjercicio): Promise<Ejercicio> {
    return this.databaseService.getEjercicio(idEjercicio);
  }
}

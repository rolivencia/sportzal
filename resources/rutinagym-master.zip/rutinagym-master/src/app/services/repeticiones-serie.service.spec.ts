import { TestBed } from '@angular/core/testing';

import { SerieService } from './repeticiones-serie.service';

describe('serieService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SerieService = TestBed.get(SerieService);
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { Serie } from '../models/repeticiones-serie.model';
import { BehaviorSubject } from 'rxjs';
import { DatabaseService } from './database/database.service';

@Injectable({
  providedIn: 'root',
})
export class SerieService {
  seriesPorEjercicioRutina: BehaviorSubject<Serie[]> = new BehaviorSubject([]);
  idEjercicioRutina: number = null;

  constructor(private databaseService: DatabaseService) {}

  CargarSeriesPorEjercicioRutina(idEjercicioRutina: number): Promise<any> {
    this.idEjercicioRutina = idEjercicioRutina;
    return new Promise((resolve, reject) => {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.databaseService
            .loadSeriesPorEjercicioRutina(this.idEjercicioRutina)
            .then(seriesPorEjercicioRutina => {
              this.seriesPorEjercicioRutina.next(seriesPorEjercicioRutina);
              console.log(
                'seriesPorEjercicioRutina',
                this.seriesPorEjercicioRutina
              );
            });
        }
      });
      resolve();
    });
  }

  AgregarSerie(serie: Serie): Promise<any> {
    return this.databaseService
      .addSerie(serie.ejercicioRutina, serie.repeticiones, serie.anotacion)
      .then(() => {
        if (this.idEjercicioRutina) {
          this.CargarSeriesPorEjercicioRutina(this.idEjercicioRutina);
        }
      });
  }

  BorrarSerie(idSerie: number): Promise<any> {
    return this.databaseService.deleteSerie(idSerie).then(() => {
      if (this.idEjercicioRutina) {
        this.CargarSeriesPorEjercicioRutina(this.idEjercicioRutina);
      }
    });
  }

  GrabarEdicionSerie(serie: Serie): Promise<any> {
    return this.databaseService.updateSerie(serie).then(() => {
      if (this.idEjercicioRutina) {
        this.CargarSeriesPorEjercicioRutina(this.idEjercicioRutina);
      }
    });
  }

  getEjercicio(idSerie: number): Promise<Serie> {
    return this.databaseService.getSerie(idSerie);
  }
}

import { TestBed } from '@angular/core/testing';

import { EjercicioRutinaService } from './ejercicio-rutina.service';

describe('EjercicioRutinaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EjercicioRutinaService = TestBed.get(EjercicioRutinaService);
    expect(service).toBeTruthy();
  });
});

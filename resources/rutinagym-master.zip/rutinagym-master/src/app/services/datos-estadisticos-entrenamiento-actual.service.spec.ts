import { TestBed } from '@angular/core/testing';

import { DatosEstadisticosEntrenamientoActualService } from './datos-estadisticos-entrenamiento-actual.service';

describe('DatosEstadisticosEntrenamientoActualService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DatosEstadisticosEntrenamientoActualService = TestBed.get(DatosEstadisticosEntrenamientoActualService);
    expect(service).toBeTruthy();
  });
});

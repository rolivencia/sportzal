import { Component, OnInit, Input } from '@angular/core';
import { Registro, RegistroConEjercicio } from 'src/app/models/registro.model';
import { RegistroService } from 'src/app/services/registro.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listado-registros-ejercicio',
  templateUrl: './listado-registros-ejercicio.component.html',
  styleUrls: ['./listado-registros-ejercicio.component.scss'],
})
export class ListadoRegistrosEjercicioComponent implements OnInit {
  @Input() ejercicioId: number;

  registrosxejercicio: RegistroConEjercicio[] = [];

  constructor(
    private registroService: RegistroService,
    private router: Router
  ) {}

  ngOnInit() {
    this.registroService
      .CargarRegistrosxEjercicio(this.ejercicioId)
      .then(() => {
        this.registroService.registrosxejercicio.subscribe(regs => {
          this.registrosxejercicio = regs;
          console.log(
            'registrosxejercicio en componente',
            this.registrosxejercicio
          );
        });
      });
  }

  BorrarRegistro(reg) {
    this.registroService.BorrarRegistro(reg.id).then(() => {
      this.registroService.registrosxejercicio.subscribe(regs => {
        this.registrosxejercicio = regs;
      });
    });
  }
  EditarRegistro(reg, slidingItem) {
    slidingItem.close();
    this.router.navigate(['/registro', reg.id, reg.nombreEjercicio]);
  }

  private EsOtroDia(indice: number): boolean {
    if (indice === 0) {
      return true;
    }

    const d1 = new Date(this.registrosxejercicio[indice - 1].fecha);
    const d2 = new Date(this.registrosxejercicio[indice].fecha);

    return (
      d1.getFullYear() !== d2.getFullYear() ||
      d1.getMonth() !== d2.getMonth() ||
      d1.getDate() !== d2.getDate()
    );
  }
}

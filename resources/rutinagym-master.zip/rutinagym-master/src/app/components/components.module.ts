import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuComponent } from './menu/menu.component';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { PopagarreComponent } from './popagarre/popagarre.component';
import { ListadoRegistrosEjercicioComponent } from './listado-registros-ejercicio/listado-registros-ejercicio.component';

@NgModule({
  declarations: [
    MenuComponent,
    PopagarreComponent,
    ListadoRegistrosEjercicioComponent,
  ],
  exports: [
    MenuComponent,
    PopagarreComponent,
    ListadoRegistrosEjercicioComponent,
  ],
  imports: [CommonModule, IonicModule, RouterModule],
})
export class ComponentsModule {}

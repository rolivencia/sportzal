import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/app/services/menu.service';
import { Observable } from 'rxjs';
import { ComponenteMenu } from 'src/app/models/menu.model';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
})
export class MenuComponent implements OnInit {
  componentesMenu: ComponenteMenu[] = [
    {
      icon: 'home',
      name: 'Inicio',
      redirectTo: '/home',
    },
    {
      icon: 'settings',
      name: 'Configuracion',
      redirectTo: '/configuracion',
    },
    {
      icon: 'fitness',
      name: 'Ejercicios del dia',
      redirectTo: '/ejercicios-rutina-activa',
    },
    {
      icon: 'contact',
      name: 'Usuario',
      redirectTo: '/usuario',
    },
  ];
  constructor() {}

  ngOnInit() {}
}

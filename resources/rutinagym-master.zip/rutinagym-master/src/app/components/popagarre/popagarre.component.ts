import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popagarre',
  templateUrl: './popagarre.component.html',
  styleUrls: ['./popagarre.component.scss'],
})
export class PopagarreComponent implements OnInit {
  imgAgarres = 'assets/images/agarres/tipos-de-agarre.png';
  constructor() {}

  ngOnInit() {}
}

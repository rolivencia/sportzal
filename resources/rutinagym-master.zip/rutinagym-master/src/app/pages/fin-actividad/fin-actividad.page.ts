import { Component, OnInit } from '@angular/core';
import { Usuario } from '../../models/usuario.model';
import { UsuarioService } from '../../services/usuario.service';
import { ActividadesDiaService } from '../../services/actividades-dia.service';
import { Router } from '@angular/router';
import { DatosEstadisticosEntrenamientoActualService } from 'src/app/services/datos-estadisticos-entrenamiento-actual.service';

@Component({
  selector: 'app-fin-actividad',
  templateUrl: './fin-actividad.page.html',
  styleUrls: ['./fin-actividad.page.scss'],
})
export class FinActividadPage implements OnInit {
  tiempoEntrenado = 0;
  tiempoEntrenadoHoras: string;
  tiempoEntrenadoMinutos: string;
  tiempoEntrenadoSegundos: string;

  tiempoActivoHoras: string;
  tiempoActivoMinutos: string;
  tiempoActivoSegundos: string;

  constructor(
    private usuarioService: UsuarioService,
    private actividadesDiaService: ActividadesDiaService,
    private datosEstadisticosEntrenamientoActualService: DatosEstadisticosEntrenamientoActualService,
    private router: Router
  ) {}

  ngOnInit() {
    this.datosEstadisticosEntrenamientoActualService.tiempoFin = new Date().getTime();
    this.tiempoEntrenado = Math.round(
      (this.datosEstadisticosEntrenamientoActualService.tiempoFin -
        this.datosEstadisticosEntrenamientoActualService.tiempoInicio) /
        1000
    );
    this.ObtenerHorasMinutosSegundos();
  }
  AvanzarDia() {
    this.usuarioService.usuario.dia++;
    if (
      this.usuarioService.usuario.dia >
      this.actividadesDiaService.actividadesdia.rutina.dias
    ) {
      this.usuarioService.usuario.dia = 1;
    }
    this.usuarioService.salvar();
    this.actividadesDiaService.CargarActividadesDia();
    this.router.navigate(['/ejercicios-rutina-activa']);
  }
  VolverRealizarDiaActual() {
    this.router.navigate(['/ejercicios-rutina-activa']);
  }
  ObtenerHorasMinutosSegundos() {
    let minutos: number, horas: number, segundos: number;
    // Entrenado (incluye descansos)
    horas = Math.trunc(this.tiempoEntrenado / 360);
    minutos = Math.trunc((this.tiempoEntrenado - horas * 60) / 60);
    segundos = Math.round(this.tiempoEntrenado - minutos * 60);
    this.tiempoEntrenadoHoras = horas.toString().padStart(2, '0');
    this.tiempoEntrenadoMinutos = minutos.toString().padStart(2, '0');
    this.tiempoEntrenadoSegundos = segundos.toString().padStart(2, '0');
    // Activo (no incluye descansos)
    let tiempoActivo: number;
    tiempoActivo =
      this.tiempoEntrenado -
      this.datosEstadisticosEntrenamientoActualService.tiempoDescanso / 1000;
    console.log(tiempoActivo);
    horas = Math.trunc(tiempoActivo / 360);
    minutos = Math.trunc((tiempoActivo - horas * 60) / 60);
    segundos = Math.round(tiempoActivo - minutos * 60);
    this.tiempoActivoHoras = horas.toString().padStart(2, '0');
    this.tiempoActivoMinutos = minutos.toString().padStart(2, '0');
    this.tiempoActivoSegundos = segundos.toString().padStart(2, '0');
  }
}

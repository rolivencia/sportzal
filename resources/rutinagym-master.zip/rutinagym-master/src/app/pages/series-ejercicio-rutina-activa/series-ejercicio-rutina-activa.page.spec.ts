import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeriesEjercicioRutinaActivaPage } from './series-ejercicio-rutina-activa.page';

describe('SeriesEjercicioRutinaActivaPage', () => {
  let component: SeriesEjercicioRutinaActivaPage;
  let fixture: ComponentFixture<SeriesEjercicioRutinaActivaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeriesEjercicioRutinaActivaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeriesEjercicioRutinaActivaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActividadDia } from 'src/app/models/actividadesdia.model';
import { ActividadesDiaService } from 'src/app/services/actividades-dia.service';
import { Router } from '@angular/router';
import { UsuarioService } from 'src/app/services/usuario.service';
import { PopoverController } from '@ionic/angular';
import { PopagarreComponent } from 'src/app/components/popagarre/popagarre.component';
import { Registro, RegistroConEjercicio } from 'src/app/models/registro.model';
import { RegistroService } from 'src/app/services/registro.service';

@Component({
  selector: 'app-series-ejercicio-rutina-activa',
  templateUrl: './series-ejercicio-rutina-activa.page.html',
  styleUrls: ['./series-ejercicio-rutina-activa.page.scss'],
})
export class SeriesEjercicioRutinaActivaPage implements OnInit {
  actividad: ActividadDia = null;
  peso = 0.0;
  repeticiones = 0;
  pasoRepeticiones = 1;
  pasoPeso = 2.5;
  sumoBarra = 0;
  selectedView = 'registro';
  constructor(
    private activatedRoute: ActivatedRoute,
    private actividadDiaService: ActividadesDiaService,
    private usuarioActualService: UsuarioService,
    private registroService: RegistroService,
    private router: Router,
    private popoverController: PopoverController
  ) {}

  ngOnInit() {
    if (this.actividadDiaService.actividadActiva) {
      this.actividad = this.actividadDiaService.actividadActiva;
      this.repeticiones = this.actividad.repeticionesPendientes[0];
      if (this.actividad.ejercicio.usaPesoCorporal) {
        this.peso = this.usuarioActualService.usuario.pesoActual;
      }
      console.log(this.actividad);
    }
  }
  IncrementarPeso() {
    this.peso += this.pasoPeso;
  }
  DecrementarPeso() {
    if (this.peso - this.pasoPeso >= 0) {
      this.peso -= this.pasoPeso;
    } else {
      this.peso = 0;
    }
  }
  IncrementarRepeticiones() {
    this.repeticiones += this.pasoRepeticiones;
  }
  DecrementarRepeticiones() {
    if (this.repeticiones - this.pasoRepeticiones >= 0) {
      this.repeticiones -= this.pasoRepeticiones;
    } else {
      this.repeticiones = 0;
    }
  }

  AgregarRegistro() {
    const registro: Registro = {
      id: 0,
      fecha: new Date().toISOString().slice(0, 10),
      ejercicio: this.actividad.ejercicio.id,
      reps: this.repeticiones,
      peso: this.peso,
      observ: '',
    };
    this.registroService.AgregarRegistro(registro).then(() => {
      const registroconejercicio: RegistroConEjercicio = {
        id: 0,
        fecha: new Date().toISOString().slice(0, 10),
        ejercicio: this.actividad.ejercicio.id,
        nombreEjercicio: this.actividad.ejercicio.nombre,
        reps: this.repeticiones,
        peso: this.peso,
        observ: '',
      };
    });
  }

  TerminarSerie() {
    // Grabo registro
    this.AgregarRegistro();
    this.actividad.repeticionesRealizadas.push(
      this.actividad.repeticionesPendientes.shift()
    );
    if (this.actividad.repeticionesPendientes.length === 0) {
      this.actividadDiaService.TerminarActividadActiva();
    } else {
      this.repeticiones = this.actividad.repeticionesPendientes[0];
    }
    this.router.navigate(['/descanso']);
  }
  SumarBarra(pesoBarra: number) {
    this.peso += pesoBarra - this.sumoBarra;
    this.sumoBarra = pesoBarra;
  }
  PesoPor2() {
    this.peso *= 2;
  }
  async VerTiposAgarres(ev: any) {
    const popover = await this.popoverController.create({
      component: PopagarreComponent,
      event: ev,
      mode: 'ios',
    });
    await popover.present();
  }
}

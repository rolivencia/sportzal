import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { SeriesEjercicioRutinaActivaPage } from './series-ejercicio-rutina-activa.page';
import { PopagarreComponent } from 'src/app/components/popagarre/popagarre.component';
import { ComponentsModule } from 'src/app/components/components.module';

const routes: Routes = [
  {
    path: '',
    component: SeriesEjercicioRutinaActivaPage
  }
];

@NgModule({
  entryComponents:[PopagarreComponent],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
    ComponentsModule
  ],
  declarations: [SeriesEjercicioRutinaActivaPage]
})
export class SeriesEjercicioRutinaActivaPageModule {}

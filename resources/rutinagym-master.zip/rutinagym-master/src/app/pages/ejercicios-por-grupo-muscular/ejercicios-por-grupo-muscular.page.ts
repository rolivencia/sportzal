import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Ejercicio } from 'src/app/models/ejercicio.model';
import { EjercicioService } from 'src/app/services/ejercicio.service';
import { GrupoMuscular } from 'src/app/models/grupo-muscular.model';
import { GrupoMuscularService } from 'src/app/services/grupo-muscular.service';
import { SolicitudIdEjercicioService } from 'src/app/services/solicitud-id-ejercicio.service';

@Component({
  selector: 'app-ejercicios-por-grupo-muscular',
  templateUrl: './ejercicios-por-grupo-muscular.page.html',
  styleUrls: ['./ejercicios-por-grupo-muscular.page.scss'],
})
export class EjerciciosPorGrupoMuscularPage implements OnInit {
  idGrupoMuscular: number;
  grupoMuscular: GrupoMuscular = {} as GrupoMuscular;
  ejerciciosPorGrupoMuscular: Ejercicio[] = [];
  constructor(
    private activatedRoute: ActivatedRoute,
    private ejercicioService: EjercicioService,
    private grupoMuscularService: GrupoMuscularService,
    private solicitudIdEjercicio: SolicitudIdEjercicioService,
    private router: Router
  ) {}
  ngOnInit() {
    this.idGrupoMuscular = parseInt(
      this.activatedRoute.snapshot.paramMap.get('id'),
      10
    );
    console.log('idGrupoMuscular', this.idGrupoMuscular);
    this.ejercicioService
      .CargarEjerciciosPorGrupo(this.idGrupoMuscular)
      .then(() => {
        this.ejercicioService.ejerciciosPorGrupoMuscular.subscribe(
          ejercicios => {
            this.ejerciciosPorGrupoMuscular = ejercicios;
            console.log(
              'ejerciciosPorGrupoMuscular',
              this.ejerciciosPorGrupoMuscular
            );
          }
        );
      });
    this.grupoMuscularService
      .getGrupoMuscular(this.idGrupoMuscular)
      .then(grupo => (this.grupoMuscular = grupo));
  }
  BorrarEjercicio(ej) {
    this.ejercicioService.BorrarEjercicio(ej.id).then(() => {
      this.ejercicioService.ejerciciosPorGrupoMuscular.subscribe(ejercicios => {
        this.ejerciciosPorGrupoMuscular = ejercicios;
        console.log(
          'ejerciciosPorGrupoMuscular',
          this.ejerciciosPorGrupoMuscular
        );
      });
    });
  }
  EditarEjercicio(ej, slidingItem) {
    slidingItem.close();
    this.router.navigate(['/ejercicio', ej.id]);
  }
  NuevoEjercicio() {
    this.router.navigate(['/ejercicio', 0]);
  }
  RetornarIdEjercicio(ej) {
    if (this.solicitudIdEjercicio.solicitudAbierta) {
      this.solicitudIdEjercicio.RetornarIdEjercicio(ej.id);
    } else {
      this.router.navigate(['/ejercicio', ej.id]);
    }
  }
}

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EjerciciosPorGrupoMuscularPage } from './ejercicios-por-grupo-muscular.page';

describe('EjerciciosPorGrupoMuscularPage', () => {
  let component: EjerciciosPorGrupoMuscularPage;
  let fixture: ComponentFixture<EjerciciosPorGrupoMuscularPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EjerciciosPorGrupoMuscularPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EjerciciosPorGrupoMuscularPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

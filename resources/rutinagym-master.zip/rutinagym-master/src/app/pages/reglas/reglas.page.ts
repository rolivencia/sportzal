import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reglas',
  templateUrl: './reglas.page.html',
  styleUrls: ['./reglas.page.scss'],
})
export class ReglasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

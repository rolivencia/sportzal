import { Component, OnInit } from '@angular/core';
import { GrupoMuscularService } from 'src/app/services/grupo-muscular.service';
import { GrupoMuscular } from 'src/app/models/grupo-muscular.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-grupos-musculares',
  templateUrl: './grupos-musculares.page.html',
  styleUrls: ['./grupos-musculares.page.scss'],
})
export class GruposMuscularesPage implements OnInit {
  gruposMusculares: GrupoMuscular[] = [];
  constructor(
    private grupoMuscularService: GrupoMuscularService,
    private router: Router
  ) {
    this.grupoMuscularService.gruposMusculares.subscribe(grupos => {
      this.gruposMusculares = grupos;
    });
  }

  ngOnInit() {}

  BorrarGrupoMuscular(grupo) {
    this.grupoMuscularService.BorrarGrupoMuscular(grupo.id).then(() => {
      this.grupoMuscularService.gruposMusculares.subscribe(grupos => {
        this.gruposMusculares = grupos;
      });
    });
  }

  EditarGrupoMuscular(grupo, slidingItem) {
    slidingItem.close();
    this.router.navigate(['/grupo-muscular', grupo.id]);
  }

  NuevoGrupoMuscular() {
    this.router.navigate(['/grupo-muscular', 0]);
  }
}

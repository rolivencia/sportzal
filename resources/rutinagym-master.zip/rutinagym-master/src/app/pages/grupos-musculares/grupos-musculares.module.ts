import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { GruposMuscularesPage } from './grupos-musculares.page';

const routes: Routes = [
  {
    path: '',
    component: GruposMuscularesPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [GruposMuscularesPage]
})
export class GruposMuscularesPageModule {}

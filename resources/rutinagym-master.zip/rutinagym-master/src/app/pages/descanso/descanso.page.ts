import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActividadesDiaService } from 'src/app/services/actividades-dia.service';
import { Platform, MenuController } from '@ionic/angular';
import { Vibration } from '@ionic-native/vibration/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { BackgroundMode } from '@ionic-native/background-mode/ngx';
import { ActividadDia } from 'src/app/models/actividadesdia.model';
import { DatosEstadisticosEntrenamientoActualService } from 'src/app/services/datos-estadisticos-entrenamiento-actual.service';

@Component({
  selector: 'app-descanso',
  templateUrl: './descanso.page.html',
  styleUrls: ['./descanso.page.scss'],
})
export class DescansoPage implements OnInit {
  inicioDescanso: number;
  finDescanso: number;
  timerDescansa: any;
  segundosDescanso: number;
  modoDescansa = false;
  // audio = new Audio();
  minutos: string;
  segundos: string;
  sonar: boolean;
  actividad: ActividadDia;
  segundosDescansoInicial: number;
  segundosDescansoTotal: number;
  tiempoFinalDescanso: number;
  msjFinDescanso: string;

  constructor(
    private router: Router,
    private actividadesDiaService: ActividadesDiaService,
    private vibration: Vibration,
    public platform: Platform,
    private localNotifications: LocalNotifications,
    private backgroundMode: BackgroundMode,
    private datosEstadisticosEntrenamientoActualService: DatosEstadisticosEntrenamientoActualService,
    public menuCtrl: MenuController
  ) {}

  ngOnInit() {
    // this.actividad = this.actividadesDiaService.actividadActiva;
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
    console.log('ionViewWillEnter descanso');
    this.inicioDescanso = new Date().getTime();
    if (!this.actividadesDiaService.actividadActiva.realizada) {
      this.actividad = this.actividadesDiaService.actividadActiva;
      this.segundosDescansoInicial = this.actividadesDiaService.actividadActiva.descanso;
    } else {
      console.log('finalizada');
      this.segundosDescansoInicial = this.actividadesDiaService.actividadesdia.rutina.descansoEntreEjercicios;
      this.actividad = this.actividadesDiaService.actividadesdia.actividades.find(
        unaactividad =>
          unaactividad.orden ===
          this.actividadesDiaService.actividadActiva.orden + 1
      );
    }
    this.segundosDescanso = this.segundosDescansoInicial;
    this.segundosDescansoTotal = this.segundosDescanso;
    this.tiempoFinalDescanso =
      new Date().getTime() + this.segundosDescanso * 1000;
    this.sonar = true;
    if (this.platform.is('cordova')) {
      this.backgroundMode.enable();
    }
    if (this.actividadesDiaService.actividadesdia.pendientes !== 0) {
      if (this.actividad.ejercicio) {
        this.msjFinDescanso = 'Descanso finalizado. Preparese para ';
        this.msjFinDescanso += 'Ej. ' + this.actividad.ejercicio.nombre + ' ';
        this.msjFinDescanso +=
          ' reps ' + this.actividad.repeticionesPendientes[0];
      } else {
        this.msjFinDescanso = 'Descanso finalizado.';
      }
    } else {
      this.msjFinDescanso =
        'Descanso finalizado. Tu entrenamiento a terminado. No olvides estirar.';
    }

    if (this.sonar && this.platform.is('cordova')) {
      this.localNotifications.schedule({
        id: 1,
        text: this.msjFinDescanso,
        sound: this.platform.is('android')
          ? 'file://sound.mp3'
          : 'file://beep.caf',
        trigger: {
          at: new Date(new Date().getTime() + this.segundosDescanso * 1000),
        },
      });
    }
    console.log('adiciona segundos');
    console.log(
      'avisa ',
      new Date(new Date().getTime() + this.segundosDescanso * 1000)
    );

    this.ObtenerMinutosSegundos();
  }

  ionViewDidEnter() {
    // this.actividad = this.actividadesDiaService.actividadActiva;
    console.log('ionViewDidEnter descanso');

    this.ObtenerMinutosSegundos();
    this.Descansar();
  }
  ObtenerMinutosSegundos() {
    let minutos: number;
    minutos = Math.trunc(this.segundosDescanso / 60);
    this.minutos = minutos.toString().padStart(2, '0');
    this.segundos = (this.segundosDescanso - minutos * 60)
      .toString()
      .padStart(2, '0');
  }

  HacerIntervaloDescanso() {
    this.timerDescansa = setTimeout(() => {
      if (this.segundosDescanso > 0) {
        // this.segundosDescanso--;
        this.segundosDescanso = Math.round(
          (this.tiempoFinalDescanso - new Date().getTime()) / 1000
        );
      }
      this.Descansar();
    }, 1000);
  }

  Descansar() {
    // console.log('tiempo restante ', this.segundosDescanso);
    console.log('actual ', new Date(new Date().getTime()));
    this.ObtenerMinutosSegundos();
    if (this.segundosDescanso <= 0) {
      /*
      if((this.sonar) && (this.platform.is("cordova"))){
      this.vibration.vibrate(1000);
      this.localNotifications.schedule({
          id: 1,
          text: 'Descanso finalizado!!! A seguir ejercitando.',
          sound: this.platform.is("android") ? 'file://sound.mp3': 'file://beep.caf'
        });
      }
      */
      this.finDescanso = new Date().getTime();
      this.datosEstadisticosEntrenamientoActualService.tiempoDescanso +=
        this.finDescanso - this.inicioDescanso;
      if (this.actividadesDiaService.actividadActiva.realizada) {
        if (this.actividadesDiaService.actividadesdia.pendientes === 0) {
          this.router.navigate(['/fin-actividad']);
        } else {
          this.router.navigate(['/ejercicios-rutina-activa']);
        }
      } else {
        this.router.navigate(['/series-ejercicio-rutina-activa']);
      }
    } else {
      this.HacerIntervaloDescanso();
    }
  }

  Terminar() {
    if (this.sonar && this.platform.is('cordova')) {
      this.localNotifications.cancelAll();
    }
    this.sonar = false;
    this.segundosDescanso = 0;
  }
  Agregar30s() {
    this.segundosDescanso += 30;
    this.tiempoFinalDescanso =
      new Date().getTime() + this.segundosDescanso * 1000;
    this.segundosDescansoTotal = this.segundosDescanso;
    if (this.sonar && this.platform.is('cordova')) {
      this.localNotifications.cancelAll();
      this.localNotifications.schedule({
        id: 1,
        text: this.msjFinDescanso,
        sound: this.platform.is('android')
          ? 'file://sound.mp3'
          : 'file://beep.caf',
        trigger: {
          at: new Date(new Date().getTime() + this.segundosDescanso * 1000),
        },
      });
    }

    this.ObtenerMinutosSegundos();
  }
  ionViewDidLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menuCtrl.enable(true);
  }
}

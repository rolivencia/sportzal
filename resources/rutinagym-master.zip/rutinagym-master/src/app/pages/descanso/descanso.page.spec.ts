import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DescansoPage } from './descanso.page';

describe('DescansoPage', () => {
  let component: DescansoPage;
  let fixture: ComponentFixture<DescansoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DescansoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DescansoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

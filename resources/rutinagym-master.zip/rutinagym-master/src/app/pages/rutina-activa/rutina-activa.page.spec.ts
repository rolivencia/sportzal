import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RutinaActivaPage } from './rutina-activa.page';

describe('RutinaActivaPage', () => {
  let component: RutinaActivaPage;
  let fixture: ComponentFixture<RutinaActivaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RutinaActivaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RutinaActivaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

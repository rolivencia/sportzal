import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rutina-activa',
  templateUrl: './rutina-activa.page.html',
  styleUrls: ['./rutina-activa.page.scss'],
})
export class RutinaActivaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

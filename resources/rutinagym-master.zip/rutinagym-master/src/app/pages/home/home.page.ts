import { Component, OnInit } from '@angular/core';
import { Platform } from '@ionic/angular';
import { SolicitudIdEjercicioService } from 'src/app/services/solicitud-id-ejercicio.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  subscription: any;
  constructor(
    private platform: Platform,
    private solicitudIdEjercicioService: SolicitudIdEjercicioService
  ) {}

  ngOnInit() {}
  // Para salir con backbutton
  ionViewDidEnter() {
    this.subscription = this.platform.backButton.subscribe(() => {
      navigator['app'].exitApp();
    });
  }

  ionViewWillLeave() {
    this.subscription.unsubscribe();
  }

  IrARegistroConEjercicio() {
    this.solicitudIdEjercicioService.EmitirSolicitudIdEjercicio(
      '/registro-manual'
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/models/usuario.model';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ActividadesDiaService } from 'src/app/services/actividades-dia.service';
import { Router } from '@angular/router';

import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
})
export class UsuarioPage implements OnInit {
  usuario: Usuario;
  constructor(
    private usuarioService: UsuarioService,
    private actividadesDiaService: ActividadesDiaService,
    private router: Router,
    public alertController: AlertController
  ) {}
  ngOnInit() {
    this.usuario = new Usuario();
    Object.assign(this.usuario, this.usuarioService.usuario);
  }
  async AvisoGuardado() {
    const alert = await this.alertController.create({
      header: 'Guardado',
      message: 'El usuario a sido guardado con exito.',
      buttons: ['OK'],
    });

    await alert.present();
  }
  Guardar() {
    if (
      this.usuario.dia > this.actividadesDiaService.actividadesdia.rutina.dias
    ) {
      this.usuario.dia = 1;
    }
    const distintoDia: boolean =
      this.usuarioService.usuario.dia !== this.usuario.dia;
    Object.assign(this.usuarioService.usuario, this.usuario);
    this.usuarioService.salvar();
    if (distintoDia) {
      this.actividadesDiaService.CargarActividadesDia();
    }
    this.AvisoGuardado();
  }
  Cancelar() {
    Object.assign(this.usuario, this.usuarioService.usuario);
  }
}

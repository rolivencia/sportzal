import { Component, OnInit } from '@angular/core';
import { EjercicioRutinaConEjercicio } from 'src/app/models/ejercicio-rutina.model';
import { ActivatedRoute, Router } from '@angular/router';
import { EjercicioRutinaService } from 'src/app/services/ejercicio-rutina.service';
import { Serie } from 'src/app/models/repeticiones-serie.model';

@Component({
  selector: 'app-ejercicios-rutina',
  templateUrl: './ejercicios-rutina.page.html',
  styleUrls: ['./ejercicios-rutina.page.scss'],
})
export class EjerciciosRutinaPage implements OnInit {
  idRutina: number;
  ejerciciosRutinaConEjercicio: EjercicioRutinaConEjercicio[] = [];

  constructor(
    private ejercicioRutinaService: EjercicioRutinaService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.idRutina = parseInt(
      this.activatedRoute.snapshot.paramMap.get('idRutina'),
      10
    );
    this.ejercicioRutinaService
      .CargarEjerciciosRutina(this.idRutina)
      .then(() => {
        this.ejercicioRutinaService.ejerciciosRutina.subscribe(
          arrayEjercicioRutinaConEjercicio => {
            this.ejerciciosRutinaConEjercicio = arrayEjercicioRutinaConEjercicio;
          }
        );
      });
    console.log(this.ejerciciosRutinaConEjercicio);
  }

  BorrarEjercicioRutina(ejercicioRutina) {
    this.ejercicioRutinaService
      .BorraEjercicioRutina(ejercicioRutina.id)
      .then(() => {
        this.ejercicioRutinaService.ejerciciosRutina.subscribe(
          arrayEjercicioRutinaConEjercicio => {
            this.ejerciciosRutinaConEjercicio = arrayEjercicioRutinaConEjercicio;
          }
        );
      });
  }

  EditarEjercicioRutina(ejercicioRutina, slidingItem) {
    slidingItem.close();
    this.router.navigate([
      '/ejercicio-rutina',
      ejercicioRutina.id,
      ejercicioRutina.rutina,
      ejercicioRutina.dia,
    ]);
  }

  AgregarEjercicioADia(dia) {
    if (dia === 0) {
      if (this.ejerciciosRutinaConEjercicio.length > 0) {
        dia =
          Math.max.apply(
            Math,
            this.ejerciciosRutinaConEjercicio.map(ejRutina => {
              return ejRutina.dia;
            })
          ) + 1;
      } else {
        dia = 1;
      }
    }
    this.router.navigate(['/ejercicio-rutina', 0, this.idRutina, dia]);
  }

  private EsOtroDiaDeRutina(indice: number): boolean {
    if (indice === 0) {
      return true;
    }
    const d1 = this.ejerciciosRutinaConEjercicio[indice - 1].dia;
    const d2 = this.ejerciciosRutinaConEjercicio[indice].dia;
    return d1 !== d2;
  }
}

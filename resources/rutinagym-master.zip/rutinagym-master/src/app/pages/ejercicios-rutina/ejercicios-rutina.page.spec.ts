import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EjerciciosRutinaPage } from './ejercicios-rutina.page';

describe('EjerciciosRutinaPage', () => {
  let component: EjerciciosRutinaPage;
  let fixture: ComponentFixture<EjerciciosRutinaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EjerciciosRutinaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EjerciciosRutinaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

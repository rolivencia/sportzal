import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvisoCalentamientoPage } from './aviso-calentamiento.page';

describe('AvisoCalentamientoPage', () => {
  let component: AvisoCalentamientoPage;
  let fixture: ComponentFixture<AvisoCalentamientoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvisoCalentamientoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvisoCalentamientoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

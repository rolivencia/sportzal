import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aviso-calentamiento',
  templateUrl: './aviso-calentamiento.page.html',
  styleUrls: ['./aviso-calentamiento.page.scss'],
})
export class AvisoCalentamientoPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}

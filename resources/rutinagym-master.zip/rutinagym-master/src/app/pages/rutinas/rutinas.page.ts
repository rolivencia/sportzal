import { Component, OnInit } from '@angular/core';
import { RutinaService } from 'src/app/services/rutina.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rutinas',
  templateUrl: './rutinas.page.html',
  styleUrls: ['./rutinas.page.scss'],
})
export class RutinasPage implements OnInit {
  constructor(private rutinaService: RutinaService, private router: Router) {}

  ngOnInit() {}

  BorrarRutina(rutina) {
    this.rutinaService.BorrarRutina(rutina.id);
  }

  NuevaRutina() {
    this.router.navigate(['/rutina', 0]);
  }

  EditarRutina(rutina) {
    this.router.navigate(['/rutina', rutina.id]);
  }
}

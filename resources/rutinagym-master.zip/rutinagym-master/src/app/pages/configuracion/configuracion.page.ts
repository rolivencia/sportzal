import { Component, OnInit } from '@angular/core';
import { ThemeService } from 'src/app/services/theme.service';
import { AjustesService } from '../../services/ajustes.service';

@Component({
  selector: 'app-configuracion',
  templateUrl: './configuracion.page.html',
  styleUrls: ['./configuracion.page.scss'],
})
export class ConfiguracionPage implements OnInit {
  constructor(
    private themeService: ThemeService,
    private ajustesService: AjustesService
  ) {}

  ngOnInit() {}
}

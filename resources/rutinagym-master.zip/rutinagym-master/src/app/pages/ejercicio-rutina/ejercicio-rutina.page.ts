import { Component, OnInit } from '@angular/core';
import { EjercicioRutina } from 'src/app/models/ejercicio-rutina.model';
import { EjercicioRutinaService } from 'src/app/services/ejercicio-rutina.service';
import { ActivatedRoute } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';
import { Serie } from 'src/app/models/repeticiones-serie.model';
import { SerieService } from 'src/app/services/repeticiones-serie.service';
import { EjercicioService } from 'src/app/services/ejercicio.service';
import { Ejercicio } from 'src/app/models/ejercicio.model';
import { SolicitudIdEjercicioService } from 'src/app/services/solicitud-id-ejercicio.service';

@Component({
  selector: 'app-ejercicio-rutina',
  templateUrl: './ejercicio-rutina.page.html',
  styleUrls: ['./ejercicio-rutina.page.scss'],
})
export class EjercicioRutinaPage implements OnInit {
  series: Serie[] = [];
  idEjercicioRutina: number;
  idRutina: number;
  dia: number;
  ejercicio: Ejercicio = {} as Ejercicio;
  repeticionActiva: Serie = {} as Serie;
  constructor(
    private ejercicioRutinaService: EjercicioRutinaService,
    private serieService: SerieService,
    private ejercicioService: EjercicioService,
    private solicitudIdEjercicioService: SolicitudIdEjercicioService,
    private activatedRoute: ActivatedRoute,
    private toast: ToastController,
    private navCtrl: NavController
  ) {}
  ngOnInit() {
    this.idEjercicioRutina = parseInt(
      this.activatedRoute.snapshot.paramMap.get('id'),
      10
    );
    this.idRutina = parseInt(
      this.activatedRoute.snapshot.paramMap.get('idRutina'),
      10
    );
    this.dia = parseInt(this.activatedRoute.snapshot.paramMap.get('dia'), 10);
    if (this.idEjercicioRutina !== 0) {
      if (
        !this.ejercicioRutinaService.ejercicioRutinaActivo ||
        this.ejercicioRutinaService.ejercicioRutinaActivo.id !==
          this.idEjercicioRutina
      ) {
        this.ejercicioRutinaService
          .getEjercicioRutina(this.idEjercicioRutina)
          .then(ejercicioRutina => {
            this.ejercicioRutinaService.ejercicioRutinaActivo = ejercicioRutina;
            this.ejercicioService
              .getEjercicio(
                this.ejercicioRutinaService.ejercicioRutinaActivo.ejercicio
              )
              .then(ej => (this.ejercicio = ej));
          });
      }
      this.serieService
        .CargarSeriesPorEjercicioRutina(this.idEjercicioRutina)
        .then(() => {
          this.serieService.seriesPorEjercicioRutina.subscribe(repsSeries => {
            this.series = repsSeries;
          });
        });
    } else {
      this.ejercicioRutinaService.ejercicioRutinaActivo = {
        id: 0,
        rutina: this.idRutina,
        dia: this.dia,
        ejercicio: 0,
        descanso: 0,
        orden: 0,
        series: 0,
        candencia: '',
        anotacion: '',
      };
    }
  }

  ModificarEjercicioEjercicioRutina() {
    this.solicitudIdEjercicioService.EmitirSolicitudIdEjercicio(
      '/ejercicio-rutina/' +
        this.idEjercicioRutina +
        '/' +
        this.idRutina +
        '/' +
        this.dia
    );
    this.solicitudIdEjercicioService.solicitudReady.subscribe(lista => {
      if (lista) {
        this.ejercicioService
          .getEjercicio(
            this.ejercicioRutinaService.ejercicioRutinaActivo.ejercicio
          )
          .then(ej => (this.ejercicio = ej));
      }
    });
  }

  GrabarEdicionEjercicioRutina() {
    this.ejercicioRutinaService
      .GrabarEdicionEjercicioRutina(
        this.ejercicioRutinaService.ejercicioRutinaActivo
      )
      .then(async () => {
        const toast = await this.toast.create({
          message: 'Modificaciones guardadas',
          duration: 3000,
        });
        toast.present();
      });
  }

  AgregarEjercicioRutina() {
    this.ejercicioRutinaService.ejercicioRutinaActivo.rutina = this.idRutina;
    this.ejercicioRutinaService.ejercicioRutinaActivo.dia = this.dia;
    this.ejercicioRutinaService
      .AgregarEjercicioRutina(this.ejercicioRutinaService.ejercicioRutinaActivo)
      .then(async () => {
        const toast = await this.toast.create({
          message: 'Ejercicio rutina guardado',
          duration: 3000,
        });
        toast.present();
      });
  }

  /*REPETICIONES-SERIE*/
  /*Luego se pasara a modulo*/
  AgregarSerie() {
    let idEjercicioRutinaActiva: number;
    idEjercicioRutinaActiva = this.ejercicioRutinaService.ejercicioRutinaActivo
      .id;
    this.repeticionActiva.ejercicioRutina = idEjercicioRutinaActiva;

    this.serieService.AgregarSerie(this.repeticionActiva).then(() => {
      this.repeticionActiva = {} as Serie;
      this.serieService
        .CargarSeriesPorEjercicioRutina(idEjercicioRutinaActiva)
        .then(() => {
          this.serieService.seriesPorEjercicioRutina.subscribe(series => {
            this.series = series;
            console.log('series despues de agregar', this.series);
          });
        });
      this.ejercicioRutinaService.ejercicioRutinaActivo.series++;
      this.GrabarEdicionEjercicioRutina();
    });
  }
  BorrarSerie(serie) {
    this.serieService.BorrarSerie(serie.id).then(() => {
      this.serieService.seriesPorEjercicioRutina.subscribe(series => {
        this.series = series;
      });
      this.ejercicioRutinaService.ejercicioRutinaActivo.series--;
      this.GrabarEdicionEjercicioRutina();
    });
  }
  EditarSerie(serie, slidingItem) {
    Object.assign(this.repeticionActiva, serie);
    console.log();
    slidingItem.close();
  }

  GrabarEdicionSerie() {
    this.serieService.GrabarEdicionSerie(this.repeticionActiva).then(() => {
      this.serieService.seriesPorEjercicioRutina.subscribe(series => {
        this.series = series;
      });
    });
    this.repeticionActiva = {} as Serie;
  }
  CancelarEdicionSerie() {
    this.repeticionActiva = {} as Serie;
  }
}

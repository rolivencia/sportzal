import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { EjercicioRutinaPage } from './ejercicio-rutina.page';

const routes: Routes = [
  {
    path: '',
    component: EjercicioRutinaPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [EjercicioRutinaPage]
})
export class EjercicioRutinaPageModule {}

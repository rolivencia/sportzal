import { Component, OnInit } from '@angular/core';
import { Rutina } from 'src/app/models/rutina.models';
import { RutinaService } from 'src/app/services/rutina.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-rutina',
  templateUrl: './rutina.page.html',
  styleUrls: ['./rutina.page.scss'],
})
export class RutinaPage implements OnInit {
  idRutina: number;
  rutina: Rutina = {} as Rutina;
  constructor(
    private rutinaService: RutinaService,
    private activatedRoute: ActivatedRoute,
    private toast: ToastController,
    private navCtrl: NavController,
    private router: Router
  ) {}

  ngOnInit() {
    this.idRutina = parseInt(
      this.activatedRoute.snapshot.paramMap.get('id'),
      10
    );
    if (this.idRutina !== 0) {
      console.log('page rutina idrutina', this.idRutina);
      this.rutinaService
        .getRutina(this.idRutina)
        .then(rutina => (this.rutina = rutina));
    } else {
      this.rutina = {
        id: null,
        nombre: '',
        imagen: '',
        detalle: '',
        sistema: '',
        dias: 0,
        descansoEntreEjercicios: 0,
      };
    }
  }
  GrabarEdicionRutina() {
    this.rutinaService.GrabarEdicionRutina(this.rutina).then(async () => {
      const toast = await this.toast.create({
        message: 'Modificaciones guardadas',
        duration: 3000,
      });
      toast.present().then(() => {
        this.navCtrl.back();
      });
    });
  }

  AgregarRutina() {
    this.rutinaService
      .AgregarRutina(this.rutina)
      .then(async idRutinaInsertada => {
        this.rutina.id = idRutinaInsertada;
        const toast = await this.toast.create({
          message: 'Rutina guardada ',
          duration: 3000,
        });
        toast.present().then(() => {
          this.EditarActividades(this.rutina);
        });
      });
  }

  EditarActividades(rutina) {
    this.router.navigate(['/ejercicios-rutina', rutina.id]);
  }
}

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EjerciciosRutinaActivaPage } from './ejercicios-rutina-activa.page';

describe('EjerciciosRutinaActivaPage', () => {
  let component: EjerciciosRutinaActivaPage;
  let fixture: ComponentFixture<EjerciciosRutinaActivaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EjerciciosRutinaActivaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EjerciciosRutinaActivaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

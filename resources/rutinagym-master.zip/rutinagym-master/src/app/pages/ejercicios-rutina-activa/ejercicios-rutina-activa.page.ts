import { Component, OnInit } from '@angular/core';
import { ActividadesDiaService } from '../../services/actividades-dia.service';
import { Router } from '@angular/router';
import { DatosEstadisticosEntrenamientoActualService } from 'src/app/services/datos-estadisticos-entrenamiento-actual.service';
import { DatabaseService } from 'src/app/services/database/database.service';

@Component({
  selector: 'app-ejercicios-rutina-activa',
  templateUrl: './ejercicios-rutina-activa.page.html',
  styleUrls: ['./ejercicios-rutina-activa.page.scss'],
})
export class EjerciciosRutinaActivaPage implements OnInit {
  constructor(
    private actividadesDiaService: ActividadesDiaService,
    private datosEstadisticosEntrenamientoActualService: DatosEstadisticosEntrenamientoActualService,
    private router: Router,
    private databaseService: DatabaseService
  ) {}

  ngOnInit() {
    if (!this.actividadesDiaService.actividadesdia) {
      this.databaseService.getDatabaseState().subscribe(rdy => {
        if (rdy) {
          this.actividadesDiaService.CargarActividadesDia().then(() => {
            console.log(
              'actividades dia',
              this.actividadesDiaService.actividadesdia
            );
          });
        }
      });
    }
  }

  RealizarActividad(indiceActividad: number) {
    console.log(indiceActividad);
    if (this.datosEstadisticosEntrenamientoActualService.tiempoInicio === 0) {
      this.datosEstadisticosEntrenamientoActualService.tiempoInicio = new Date().getTime();
    }
    this.actividadesDiaService.CargarActividadActivaPorIndice(indiceActividad);
    this.router.navigate(['/series-ejercicio-rutina-activa']);
  }
}

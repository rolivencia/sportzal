import { Component, OnInit } from '@angular/core';
import { RegistroService } from 'src/app/services/registro.service';
import { Ejercicio } from 'src/app/models/ejercicio.model';
import { EjercicioService } from 'src/app/services/ejercicio.service';
import { ActivatedRoute } from '@angular/router';
import { RegistroConEjercicio, Registro } from 'src/app/models/registro.model';
import { SolicitudIdEjercicioService } from 'src/app/services/solicitud-id-ejercicio.service';

@Component({
  selector: 'app-registro-manual',
  templateUrl: './registro-manual.page.html',
  styleUrls: ['./registro-manual.page.scss'],
})
export class RegistroManualPage implements OnInit {
  ejercicio: Ejercicio = {} as Ejercicio;
  registrosxejercicio: RegistroConEjercicio[] = [];
  registro: Registro = {} as Registro;
  constructor(
    private registroService: RegistroService,
    private ejercicioService: EjercicioService,
    private solicitudIdEjercicioSerice: SolicitudIdEjercicioService,
    private activatedRoute: ActivatedRoute
  ) {}
  ngOnInit() {
    const idEjercicio = parseInt(
      this.activatedRoute.snapshot.paramMap.get('ejercicio'),
      10
    );
    console.log('idEjercicio', idEjercicio);
    this.ejercicioService.getEjercicio(idEjercicio).then(ej => {
      this.ejercicio = ej;
    });
    this.registroService.CargarRegistrosxEjercicio(idEjercicio).then(() => {
      this.registroService.registrosxejercicio.subscribe(regs => {
        this.registrosxejercicio = regs;
        console.log(
          'registrosxejercicio en ngoninit',
          this.registrosxejercicio
        );
      });
    });
  }

  AgregarRegistro() {
    this.registro.ejercicio = this.ejercicio.id;
    this.registro.observ = '';
    this.registroService.AgregarRegistro(this.registro).then(() => {
      this.registro = {} as Registro;
      this.solicitudIdEjercicioSerice.CerrarSolicitud();
      this.registroService
        .CargarRegistrosxEjercicio(this.ejercicio.id)
        .then(() => {
          this.registroService.registrosxejercicio.subscribe(regs => {
            this.registrosxejercicio = regs;
            console.log(
              'registrosxejercicio despues de agregar',
              this.registrosxejercicio
            );
          });
        });
    });
  }
  BorrarRegistro(reg) {
    this.registroService.BorrarRegistro(reg.id).then(() => {
      this.registroService.registrosxejercicio.subscribe(regs => {
        this.registrosxejercicio = regs;
      });
    });
  }
  EditarRegistro(reg, slidingItem) {
    Object.assign(this.registro, reg);
    slidingItem.close();
  }

  GrabarEdicionRegistro() {
    this.registroService.GrabarEdicionRegistro(this.registro).then(() => {
      this.registroService.registrosxejercicio.subscribe(regs => {
        this.registrosxejercicio = regs;
      });
    });
    this.registro = {} as Registro;
  }
  CancelarEdicionRegistro() {
    this.registro = {} as Registro;
  }

  private EsOtroDia(indice: number): boolean {
    if (indice === 0) {
      return true;
    }
    const d1 = new Date(this.registrosxejercicio[indice - 1].fecha);
    const d2 = new Date(this.registrosxejercicio[indice].fecha);

    return (
      d1.getFullYear() !== d2.getFullYear() ||
      d1.getMonth() !== d2.getMonth() ||
      d1.getDate() !== d2.getDate()
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { Ejercicio } from 'src/app/models/ejercicio.model';
import { EjercicioService } from 'src/app/services/ejercicio.service';
import { ActivatedRoute } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';
import { GrupoMuscular } from 'src/app/models/grupo-muscular.model';
import { GrupoMuscularService } from 'src/app/services/grupo-muscular.service';

@Component({
  selector: 'app-ejercicio',
  templateUrl: './ejercicio.page.html',
  styleUrls: ['./ejercicio.page.scss'],
})
export class EjercicioPage implements OnInit {
  gruposMusculares: GrupoMuscular[] = [];
  idEjercicio: number;
  ejercicio: Ejercicio = {} as Ejercicio;
  constructor(
    private ejercicioService: EjercicioService,
    private activatedRoute: ActivatedRoute,
    private toast: ToastController,
    private navCtrl: NavController,
    private grupoMuscularService: GrupoMuscularService
  ) {}

  ngOnInit() {
    this.idEjercicio = parseInt(
      this.activatedRoute.snapshot.paramMap.get('id'),
      10
    );
    console.log('page ejercicio idEjercicio', this.idEjercicio);

    if (this.idEjercicio !== 0) {
      this.ejercicioService
        .getEjercicio(this.idEjercicio)
        .then(ej => (this.ejercicio = ej));
    } else {
      const grupoEjercicio: number = this.ejercicioService.idGrupoMuscular
        ? this.ejercicioService.idGrupoMuscular
        : 0;
      this.ejercicio = {
        id: null,
        grupoMuscular: grupoEjercicio,
        nombre: '',
        imagen: '',
        video: '',
        detalle: '',
        usaAgarres: false,
        usaBarra: false,
        usaMancuernas: false,
        usaPesoCorporal: false,
      };
    }
    this.grupoMuscularService.gruposMusculares.subscribe(grupos => {
      this.gruposMusculares = grupos;
    });
  }
  GrabarEdicionEjercicio() {
    this.ejercicioService
      .GrabarEdicionEjercicio(this.ejercicio)
      .then(async () => {
        const toast = await this.toast.create({
          message: 'Modificaciones guardadas',
          duration: 3000,
        });
        toast.present().then(() => {
          this.navCtrl.back();
        });
      });
  }

  AgregarEjercicio() {
    this.ejercicioService.AgregarEjercicio(this.ejercicio).then(async () => {
      const toast = await this.toast.create({
        message: 'Ejercicio guardado',
        duration: 3000,
      });
      toast.present().then(() => {
        this.navCtrl.back();
      });
    });
  }
}

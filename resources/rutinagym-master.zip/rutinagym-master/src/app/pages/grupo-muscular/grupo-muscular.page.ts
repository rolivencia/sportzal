import { Component, OnInit } from '@angular/core';
import { GrupoMuscular } from 'src/app/models/grupo-muscular.model';
import { GrupoMuscularService } from 'src/app/services/grupo-muscular.service';
import { ActivatedRoute } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-grupo-muscular',
  templateUrl: './grupo-muscular.page.html',
  styleUrls: ['./grupo-muscular.page.scss'],
})
export class GrupoMuscularPage implements OnInit {
  idGrupoMuscular: number;
  grupoMuscular: GrupoMuscular = {} as GrupoMuscular;
  constructor(
    private grupoMuscularService: GrupoMuscularService,
    private activatedRoute: ActivatedRoute,
    private toast: ToastController,
    private navCtrl: NavController
  ) {}

  ngOnInit() {
    this.idGrupoMuscular = parseInt(
      this.activatedRoute.snapshot.paramMap.get('id'),
      10
    );
    if (this.idGrupoMuscular !== 0) {
      console.log('page grupo muscular idgrupomuscular', this.idGrupoMuscular);
      this.grupoMuscularService
        .getGrupoMuscular(this.idGrupoMuscular)
        .then(grupo => (this.grupoMuscular = grupo));
    } else {
      this.grupoMuscular = { id: null, nombre: '', imagen: '' };
    }
  }
  GrabarEdicionGrupoMuscular() {
    this.grupoMuscularService
      .GrabarEdicionGrupoMuscular(this.grupoMuscular)
      .then(async () => {
        const toast = await this.toast.create({
          message: 'Modificaciones guardadas',
          duration: 3000,
        });
        toast.present().then(() => {
          this.navCtrl.back();
        });
      });
  }

  AgregarGrupoMuscular() {
    this.grupoMuscularService
      .AgregarGrupoMuscular(this.grupoMuscular)
      .then(async () => {
        const toast = await this.toast.create({
          message: 'Grupo muscular guardado',
          duration: 3000,
        });
        toast.present().then(() => {
          this.navCtrl.back();
        });
      });
  }
}

import { Component, OnInit } from '@angular/core';
import { Registro } from 'src/app/models/registro.model';
import { RegistroService } from 'src/app/services/registro.service';
import { ActivatedRoute } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {
  idRegistro: number;
  nombreEjercicio: string;
  registro: Registro = {} as Registro;
  constructor(
    private registroService: RegistroService,
    private activatedRoute: ActivatedRoute,
    private toast: ToastController,
    private navCtrl: NavController
  ) {}

  ngOnInit() {
    this.idRegistro = parseInt(
      this.activatedRoute.snapshot.paramMap.get('id'),
      10
    );
    this.nombreEjercicio = this.activatedRoute.snapshot.paramMap.get(
      'nombreEjercicio'
    );
    console.log('page registro id reg', this.idRegistro);
    console.log('page registro nombreEjercicio', this.nombreEjercicio);
    this.registroService
      .getRegistro(this.idRegistro)
      .then(reg => (this.registro = reg));
  }
  GrabarEdicionRegistro() {
    this.registroService.GrabarEdicionRegistro(this.registro).then(async () => {
      const toast = await this.toast.create({
        message: 'Modificaciones guardadas',
        duration: 3000,
      });
      toast.present().then(() => {
        this.navCtrl.back();
      });
    });
  }

  AgregarRegistro() {
    this.registroService.AgregarRegistro(this.registro).then(async () => {
      const toast = await this.toast.create({
        message: 'Registro guardado',
        duration: 3000,
      });
      toast.present().then(() => {
        this.navCtrl.back();
      });
    });
  }
}

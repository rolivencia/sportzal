export interface Rutina {
  id: number;
  nombre: string;
  detalle: string;
  imagen: string;
  dias: number;
  sistema: string;
  descansoEntreEjercicios: number;
}

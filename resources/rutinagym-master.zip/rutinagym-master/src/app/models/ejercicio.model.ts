export class Ejercicio {
  constructor(
    public id: number,
    public nombre: string,
    public imagen: string,
    public video: string,
    public detalle: string,
    public grupoMuscular: number,
    public usaBarra: boolean,
    public usaMancuernas: boolean,
    public usaPesoCorporal: boolean,
    public usaAgarres: boolean
  ) {}
}

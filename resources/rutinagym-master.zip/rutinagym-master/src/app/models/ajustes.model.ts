export class Ajustes {
  constructor(public temaOscuro: boolean = true) {}
}

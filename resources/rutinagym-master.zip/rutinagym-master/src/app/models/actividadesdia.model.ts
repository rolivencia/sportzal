import { Rutina } from './rutina.models';
import { Ejercicio } from './ejercicio.model';

export class ActividadesDia {
  constructor(
    public rutina: Rutina,
    public dia: number,
    public actividades: ActividadDia[],
    public pendientes: number,
    public realizadas: number,
    public canceladas: number
  ) {}
}
export class ActividadDia {
  constructor(
    public ejercicio: Ejercicio,
    public descanso: number,
    public orden: number,
    public series: number,
    public candencia: string,
    public anotacion: string,

    public repeticiones: number[],
    public anotaciones: string[],

    public pesos: number[],
    public repeticionesRealizadas: number[],
    public repeticionesPendientes: number[],
    public pendiente: boolean,
    public realizada: boolean,
    public cancelada: boolean
  ) {}
}

export interface Serie {
  id: number;
  ejercicioRutina: number;
  repeticiones: number;
  anotacion: string;
}

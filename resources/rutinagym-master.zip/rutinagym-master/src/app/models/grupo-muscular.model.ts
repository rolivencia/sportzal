export class GrupoMuscular {
  constructor(
    public id: number,
    public nombre: string,
    public imagen: string
  ) {}
}

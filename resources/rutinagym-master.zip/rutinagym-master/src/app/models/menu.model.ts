export class ComponenteMenu {
  constructor(
    public icon: string,
    public name: string,
    public redirectTo: string
  ) {}
}

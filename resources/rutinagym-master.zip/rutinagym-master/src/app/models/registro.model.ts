export interface Registro {
  id: number;
  fecha: string;
  ejercicio: number;
  reps: number;
  peso: number;
  observ: string;
}

export interface RegistroConEjercicio {
  id: number;
  fecha: string;
  ejercicio: number;
  nombreEjercicio: string;
  reps: number;
  peso: number;
  observ: string;
}

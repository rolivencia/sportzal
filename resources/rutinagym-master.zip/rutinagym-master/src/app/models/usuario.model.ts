export class Usuario {
  constructor(
    public id: number = 0,
    public nombre: string = '',
    public rutina: number = 0,
    public dia: number = 0,
    public ronda: number = 0,
    public diasEntreno: number = 0,
    public pesoActual: number = 0,
    public alturaActual: number = 0
  ) {}
}

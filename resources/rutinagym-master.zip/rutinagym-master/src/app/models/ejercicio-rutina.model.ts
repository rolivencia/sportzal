import { Ejercicio } from './ejercicio.model';

export class EjercicioRutina {
  constructor(
    public id: number,
    public rutina: number,
    public dia: number,
    public ejercicio: number,
    public descanso: number,
    public orden: number,
    public series: number,
    public candencia: string,
    public anotacion: string
  ) {}
}

export class EjercicioRutinaConEjercicio {
  constructor(
    public id: number,
    public rutina: number,
    public dia: number,
    public ejercicio: Ejercicio,
    public descanso: number,
    public repeticiones: number[],
    public anotaciones: string[],
    public orden: number,
    public series: number,
    public candencia: string,
    public anotacion: string
  ) {}
}
